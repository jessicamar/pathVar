# read in RPKM values 660 samples and 53,934 genes
ThousandGenedat <- read.table("GD660.GeneQuantRPKM.txt",header=T,sep="\t",stringsAsFactors=FALSE)
range(ThousandGenedat[,c(-1,-2,-3,-4)]) # 0 to 76148.96
# normalize data
rownames(ThousandGenedat) <- ThousandGenedat[,2] # put gene names as rownames
ThousandGenedat <- ThousandGenedat[,c(-1,-2,-3,-4)] # remove coordinates
ThousandGenedatLog=log(ThousandGenedat+1,base=2) # new range 0 to 16.21656
range(ThousandGenedatLog) # 0.00000 to 16.21656

# convert ensembl to gene names
modifiedGeneNames <- strsplit(rownames(ThousandGenedat),split="[.]")
modifiedGeneNames <- lapply(modifiedGeneNames, function(x) x[1])
modifiedGeneNames <- unlist(modifiedGeneNames)
rownames(ThousandGenedatLog) <- modifiedGeneNames # 53934 genes to start

library("AnnotationDbi")
library(org.Hs.eg.db)
convertIDs <- function( ids, from, to, db, ifMultiple=c("putNA", "useFirst")) {
  stopifnot( inherits( db, "AnnotationDb" ) )
  ifMultiple <- match.arg( ifMultiple )
  suppressWarnings( selRes <- AnnotationDbi::select(
    db, keys=ids, keytype=from, columns=c(from,to) ) )
  if ( ifMultiple == "putNA" ) {
    duplicatedIds <- selRes[ duplicated( selRes[,1] ), 1 ]
    selRes <- selRes[ ! selRes[,1] %in% duplicatedIds, ]
  }
  return( selRes[ match( ids, selRes[,1] ), 2 ] )
}
ENSEMBLtoGene <- convertIDs(rownames(ThousandGenedatLog), "ENSEMBL", "SYMBOL",org.Hs.eg.db)

convertNamesNoNA <- ENSEMBLtoGene[which(!is.na(ENSEMBLtoGene))] # 25370 genes left

### aggregate method
unknownENSEMBLremovedDat <- ThousandGenedatLog[-which(is.na(ENSEMBLtoGene)),] # remove ensembl IDs that could not be converted to symbols
unknownENSEMBLremovedDat <- cbind(convertNamesNoNA,unknownENSEMBLremovedDat)
aggre <- aggregate(unknownENSEMBLremovedDat[,seq(2,length(colnames(unknownENSEMBLremovedDat)))],by=list(unknownENSEMBLremovedDat[,1]), FUN=mean, na.rm=TRUE)
rownames(aggre) <- aggre[,1]
aggre <- aggre[,-1] # 25341 before filtering

#uniqueThousandGeneDat=NULL
#for(i in 1:length(na.omit(unique(ENSEMBLtoGene)))) {
#    uniqueThousandGeneDat=rbind(uniqueThousandGeneDat,colMeans(ThousandGenedatLog[which(ENSEMBLtoGene==(na.omit(unique(ENSEMBLtoGene))[i])),]))
#}
#rownames(uniqueThousandGeneDat) <- na.omit(unique(ENSEMBLtoGene)) # 25341 genes as of now

# reorder aggre
#geneLocsInOtherDat <- sapply(rownames(uniqueThousandGeneDat),function(x) match(x, rownames(aggre)))
#aggre <- aggre[geneLocsInOtherDat,]

qc <- apply(uniqueThousandGeneDat, 1, function(x) sum(x>=1))
uniqueThousandGeneDatLogFilt=uniqueThousandGeneDat[qc >= .75*(dim(dat)[2]),] # 11945 left

# pathVar time!
library(pathVar)
pdf("diagnosticVarPlots.1000genome.pdf",width=14)
diagnosticsVarPlots(uniqueThousandGeneDatLogFilt) # SD R= -0.13 MAD R = -0.1 CV R = -0.65
dev.off()
# MAD is best

resOneSamKEGG <- pathVarOneSample(uniqueThousandGeneDatLogFilt,pways.kegg,test="exact",varStat="mad")
resOneSamKEGG@numOfClus # 4 clusters
sigOneSamKEGG <- sigPway(resOneSamKEGG,0.01) # 9 significant pathways
length(names(sigOneSamKEGG@genesInSigPways1))

resOneSamReactome <- pathVarOneSample(uniqueThousandGeneDatLogFilt,pways.reactome,test="exact",varStat="mad")
sigOneSamReactome <- sigPway(resOneSamReactome,0.01) # no significant pathways
names(sigOneSamReactome@genesInSigPways1) # 19 sig pathways

resOneSamKEGGmean <- pathVarOneSample(uniqueThousandGeneDatLogFilt,pways.kegg,test="exact",varStat="mean")
sigOneSamKEGGMean <- sigPway(resOneSamKEGGmean,0.01) # 84 sig pathways

resOneSamReactomeMean <- pathVarOneSample(uniqueThousandGeneDatLogFilt,pways.reactome,test="exact",varStat="mean")
sigOneSamReactomeMean <- sigPway(resOneSamReactomeMean,0.01) # 308 sig pathways

##### pathVar on Mouse Brain Data Set
load("pways.kegg.mouse.RData")
library(GEOquery)
gse <- getGEO("GSE26500")
mouseBrainDat <- exprs(gse[[1]])


### map probes to gene symbols
probeMap <- read.table("MouseRef-8_V2_0_R3_11278551_A.txt",sep="\t",header=T,skip=8,nrows=25697,quote="",stringsAsFactors=FALSE)
symLocs <- sapply(rownames(mouseBrainDat), function(x) match(x,probeMap[,14]))
symbols <- probeMap[symLocs,12]
#rownames(mouseBrainDat) <- symbols
hippoDat <- mouseBrainDat[,1:100]
striatumDat <- mouseBrainDat[,seq(101,length(colnames(mouseBrainDat)))]
## find negative values and set to NA
#Negs <- apply(hippoDat,1,function(x) x<0)
hippoDat[which(hippoDat < 0)] <- NA
hippDatFrame <- as.data.frame(hippoDat)

l=NULL
for(i in 1:length(na.omit(unique(symbols)))) {
    l=rbind(l,colMeans(hippDatFrame[which(symbols==(na.omit(unique(symbols))[i])),]))
}
rownames(l) <- na.omit(unique(symbols))

dat=log(l+1,base=2)
#qc <- apply(dat, 1, function(x) sum(x>=1))
#dat.filt2=dat[which(qc >= .75*(dim(dat)[2])),] # removes gene with NA sample
library(pathVar)
pdf("diagnosticVarPlots.mouseHippo.pdf",width=14)
diagnosticsVarPlots(dat) # SD R= 0.538 R=MAD R = 0.402 CV R = 0.257
dev.off()

resOneSamMouseKEGG <- pathVarOneSample(dat,pways.kegg.mouse,test="exact",varStat="cv")
resOneSamMouseKEGG@numOfClus # 4 clusters
sigOneSamMouseKEGG <- sigPway(resOneSamMouseKEGG,0.01)
length(names(sigOneSamMouseKEGG@genesInSigPways1)) # 4 significant pathways.

## pathVar on hyppocampus using mean instead of CV

resOneSamMouseKEGGmean <- pathVarOneSample(dat,pways.kegg.mouse,test="exact",varStat="mean")
sigOneSamMouseKEGGmean <- sigPway(resOneSamMouseKEGGmean,0.01) # 98 pathways at 0.01 significance level

## path Var 2 group test on mouse data

striatumDatFrame <- as.data.frame(striatumDat)
uniqueStriatumDat=NULL
for(i in 1:length(na.omit(unique(symbols)))) {
    uniqueStriatumDat=rbind(uniqueStriatumDat,colMeans(striatumDatFrame[which(symbols==(na.omit(unique(symbols))[i])),]))
}
rownames(uniqueStriatumDat) <- na.omit(unique(symbols)) # 18138 after combining genes

logStiatumDat <- log(uniqueStriatumDat+1,2)
qc <- apply(logStiatumDat, 1, function(x) sum(x>=1))
logStiatumDatFilt=logStiatumDat[which(qc >= .75*(dim(logStiatumDat)[2])),] # no reads filtered out

library(pathVar)
pdf("diagnosticVarPlots.mouseStiatum.pdf",width=14)
diagnosticsVarPlots(logStiatumDatFilt) # SD R=0.474 MAD R=0.438 COV R=0.223
dev.off()

### one sample pathVar on striatum using COV

resOneSamMouseStriatumKEGG <- pathVarOneSample(logStiatumDatFilt, pways.kegg.mouse,test="exact",varStat="cv")
sigOneSamMouseStriatumKEGG <- sigPway(resOneSamMouseStriatumKEGG,0.01) # 2 pathways at 0.01 sig level
names(sigOneSamMouseStriatumKEGG@genesInSigPways1)

resOneSamMouseStriatumKEGGmean <- pathVarOneSample(logStiatumDatFilt, pways.kegg.mouse,test="exact",varStat="mean")
sigOneSamMouseStriatumKEGGmean <- sigPway(resOneSamMouseStriatumKEGGmean, 0.01) # 92 sig pathways
names(sigOneSamMouseStriatumKEGGmean@genesInSigPways1)

### combine the 2 data frames. First 100 columns are hippocampus. Next 98 are stiatum

combinedMouseBrain <- cbind(dat,logStiatumDatFilt)
mouseGroup <- c(rep(1,100),rep(2,98))
set.seed(1)
resMouseBrainTwoSamCont <- pathVarTwoSamplesCont(combinedMouseBrain,pways.kegg.mouse,groups=as.factor(mouseGroup),varStat="cv")
sigMouseBrainTwoSamCont=sigPway(resMouseBrainTwoSamCont,0.1) # 102 sig pathways at 0.1 significance

set.seed(1)
resMouseBrainTwoSamDisc=pathVarTwoSamplesDisc(combinedMouseBrain,pways.kegg.mouse,groups=as.factor(mouseGroup),test="exact",varStat="cv")
sigMouseBrainTwoSamDisc=sigPway(resMouseBrainTwoSamDisc,0.01) # 116 sig pathways at 0.01 significance

### do the 2 group mouse test using the mean

set.seed(1)
resMouseBrainTwoSamContMean <- pathVarTwoSamplesCont(combinedMouseBrain,pways.kegg.mouse,groups=as.factor(mouseGroup),varStat="mean")
sigMouseBrainTwoSamContMean <- sigPway(resMouseBrainTwoSamContMean,0.1) # 4 pathways found

set.seed(1)
resMouseBrainTwoSamDiscMean <- pathVarTwoSamplesDisc(combinedMouseBrain,pways.kegg.mouse,groups=as.factor(mouseGroup),test="exact",varStat="mean")
sigMouseBrainTwoSamDiscMean <- sigPway(resMouseBrainTwoSamDiscMean,0.1) # no significant pathways

pdf("diagnosticVarPlots.mouse.Stitaum.Hippocampus.pdf",width=14)
diagnosticsVarPlots_2(logStiatumDatFilt,dat) # SD R= 0.505 MAD R=0.42 COV R=0.239
dev.off()

#### distribution counts plot for Two samples case

vs <- apply(combinedMouseBrain, 1, function(x) sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE))
var_1 <- resMouseBrainTwoSamDisc@var1
var_2 <- resMouseBrainTwoSamDisc@var2
cut <- quantile(vs, probs = c(1/3, 2/3))
mixHippo <- rep(NA, dim(dat)[1])
mixHippo[var_1 <= cut[1]] <- 1
mixHippo[var_1 <= cut[2] & var_1 > cut[1]] <- 2
mixHippo[var_1 > cut[2]] <- 3
names(mixHippo) <- row.names(dat)
# In which cluster each gene is
mixStiatum <- rep(NA, dim(logStiatumDatFilt)[1])
mixStiatum[var_2 <= cut[1]] <- 1
mixStiatum[var_2 <= cut[2] & var_2 > cut[1]] <- 2
mixStiatum[var_2 > cut[2]] <- 3
names(mixStiatum) <- row.names(logStiatumDatFilt)

table(mixHippo)
#1    2    3
#7144 5568 5426
table(mixStiatum)
#1     2     3
#10227  4002  3909

pathHippo <- as.data.frame(table(mixHippo))
colnames(pathHippo) <- c("Cluster", "Number_of_genes")
pathStiatum <- as.data.frame(table(mixStiatum))
colnames(pathStiatum) <- c("Cluster", "Number_of_genes")

plotPathHippo <- ggplot(pathHippo, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("hippocampus") + xlab("") + ylim(0, 10227)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
plotPathStiatum <- ggplot(pathStiatum, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("stiatum") + xlab("") + ylim(0, 10227)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))

pdf("hippoVSstiatumCounts.pdf",width=10,height=7)
grid.arrange(arrangeGrob(plotPathHippo, plotPathStiatum, nrow = 1))
dev.off()

# function to plot distribution counts for Two sample case
plotAllTwoSampleDistributionCounts <- function(dat,pvalue_results,plotName) {
    groups <- pvalue_results@groups
    groupNames <- levels(groups)
    if (length(groupNames) > 2 | groupNames[1] != "1" | groupNames[2] != "2") {
        stop("Error: Only 2 groups may be compared. They must be labeled 1 and 2 in the groups parameter.")
    }
    groups <- as.factor(as.numeric(groups))
    dat.mat_1 <- dat[, which(groups == 1)]
    dat.mat_2 <- dat[, which(groups == 2)]
    if (pvalue_results@varStat == "sd") {
        vs <- apply(dat, 1, function(x) sd(x, na.rm = TRUE))
    } else if (pvalue_results@varStat == "cv") {
        vs <- apply(dat, 1, function(x) sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE))
    } else if (pvalue_results@varStat == "mean") {
        vs <- apply(dat, 1, function(x) mean(x, na.rm = TRUE))
    } else if (pvalue_results@varStat == "mad") {
        vs <- apply(dat, 1, function(x) mad(x, na.rm = TRUE))
    }
    var_1 <- pvalue_results@var1
    var_2 <- pvalue_results@var2
    #clusterNumber <- length(pvalue_results@pwayCounts1[[1]])
    clusterNumber <- 3 # we always have 3 clusters for the 2 sample case
    clusterNumber <- clusterNumber - 1 # if we have 3 clusters, we want to get quantile of 1 and 2
    cut <- quantile(vs, probs = 1:clusterNumber/(clusterNumber+1))
    # put genes into 1 of 3 distince clusters
    mixDat1 <- apply(sapply(cut, function(x) var_1 <= x), 1, function(y) if(!is.na(match(TRUE, y))){match(TRUE, y)} else {length(y)+1})
    mixDat2 <- apply(sapply(cut, function(x) var_2 <= x), 1, function(y) if(!is.na(match(TRUE, y))){match(TRUE, y)} else {length(y)+1})
    pathDat1 <- as.data.frame(table(mixDat1))
    colnames(pathDat1) <- c("Cluster", "Number_of_genes")
    pathDat2 <- as.data.frame(table(mixDat2))
    colnames(pathDat2) <- c("Cluster", "Number_of_genes")
    #results <- sapply(significant, function(x) apply(rbind(sigPwayCounts2[x][[1]], sigPwayCounts1[x][[1]]/sum(sigPwayCounts1[x][[1]])),
    #2, function(y) multinomial.test(c(y[1], sum(sigPwayCounts2[x][[1]]) - y[1]), prob = c(y[2],
    #1 - y[2]))$p.value))
    f <- file()
    sink(file = f)
    results <- apply(rbind(pathDat2[,2],pathDat1[,2]/pathDat1[,2]/sum(pathDat1[,2])), 2, function(y) multinomial.test(c(y[1], sum(pathDat2[,2]) - y[1]), prob = c(y[2],1 - y[2]))$p.value)
    sink()
    close(f)
    row.names(results) <- NULL
    numOfSigCat <- length(which(results < pvalue))
    category <- which(results < pvalue)
    if (numOfSigCat == 0) {
        category <- 0
    }
    plotPathDat1 <- ggplot(pathDat1, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("Group 1") + xlab("") + ylim(0, max(pathDat1[,2], pathDat2[,2]))
    plotPathDat2 <- ggplot(pathDat2, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("Group 2") + xlab("") + ylim(0, max(pathDat1[,2], pathDat2[,2]))
    if(numOfSigCat > 0) {
        plotPathDat1 <- plotPathDat1 + annotate("text", x = category, y = pathDat1[category +
        0.1, 2], label = rep("*", numOfSigCat), color = "red", size = 15)
        plotPathDat2 <- plotPathDat2 + annotate("text", x = category, y = pathDat2[category +
        0.1, 2], label = rep("*", numOfSigCat), color = "red", size = 15)
    } else {
        plotPathDat1 <- plotPathDat1 + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
        plotPathDat2 <- plotPathDat2 + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
    }
    pdf(plotName,width=10,height=7)
    grid.arrange(arrangeGrob(plotPathDat1, plotPathDat2, nrow = 1))
    dev.off()
}


##### diagnostics Var plots for the 2 sample case
diagnosticsVarPlotsTwoSample <- function(dat,groups) {
    
    dat.mat1 <-
    # Compute the sd, mean,cv and mad for each gene
    dat.sd1 <- apply(dat.mat1, 1, sd, na.rm = TRUE)
    dat.avg1 <- rowMeans(dat.mat1, na.rm = TRUE)
    dat.cv1 <- apply(dat.mat1, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad1 <- apply(dat.mat1, 1, mad, na.rm = TRUE)
    dat.sd2 <- apply(dat.mat2, 1, sd, na.rm = TRUE)
    dat.avg2 <- rowMeans(dat.mat2, na.rm = TRUE)
    dat.cv2 <- apply(dat.mat2, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad2 <- apply(dat.mat2, 1, mad, na.rm = TRUE)
    data.sd <- data.frame(standDev = c(dat.sd1,dat.sd2), avg = c(dat.avg1,dat.avg2))
    data.mad <- data.frame(medAbsDev = c(dat.mad1,dat.mad2), avg = c(dat.avg1,dat.avg2))
    data.cv <- data.frame(cv = c(dat.cv1,dat.cv2), avg = c(dat.avg1,dat.avg2))
    # Plot the mean vs the standard deviation and give the correlation between both in the title.
    plotSD <- ggplot(data.sd, aes(x = avg, y = standDev)) + geom_point(colour = "grey60") +
    stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") +
    ylab("Standard Deviation (SD)") + ggtitle(paste(c("Standard Deviation [ R=", round(cor(data.sd$standDev,
    data.sd$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the median absolute deviation and give the correlation between both in the title.
    plotMAD <- ggplot(data.mad, aes(x = avg, y = medAbsDev)) + geom_point(colour = "grey60") +
    stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") +
    ylab("Median Absolute Deviation (MAD)") + ggtitle(paste(c("Median Absolute Deviation [ R=",
    round(cor(data.mad$medAbsDev,data.mad$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the coefficient of variation and give the correlation between both in the title.
    plotCV <- ggplot(data.cv, aes(x = avg, y = cv)) + geom_point(colour = "grey60") + stat_smooth(method = loess) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(),
    axis.line = element_line(colour = "black")) + xlab("Average") + ylab("Coefficient of Variation (CV)") +
    ggtitle(paste(c("Coefficient of Variation [ R=", round(cor(data.cv$cv,
    data.cv$avg), 3), "]"),
    collapse = " "))
    grid.arrange(arrangeGrob(plotSD, plotMAD, plotCV, nrow = 1))
}

#### distribution counts for the 2 sample case


