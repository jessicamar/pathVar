
load("~/real_dataset/Yan/dat_esc.RData")
library(pathVar)



######sd

t0 <- Sys.time() 
exact.test.kegg_sd <- pathVarOneSample(dat.esc, pways=pways.kegg,test="exact",varStat="sd")
t1 <- Sys.time()
t1-t0
#Time difference of 5 secs
write.table(exact.test.kegg_sd@tablePway, file="table_Yan_esc_exact_kegg_sd.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_sd <- pathVarOneSample(dat.esc, pways=pways.reactome,test="exact",varStat="sd")
t1 <- Sys.time()
t1-t0
#Time difference of 19 secs

write.table(exact.test.reactome_sd@tablePway, file="table_Yan_esc_exact_reactome_sd.txt", sep="\t", col.names=T, row.names=F, quote=F)

#sig category exact
sig_kegg.exact_sd=sigPway(exact.test.kegg_sd,0.01)
sig_reactome.exact_sd=sigPway(exact.test.reactome_sd,0.01)


length(sig_kegg.exact_sd@genesInSigPways1)#11
length(sig_reactome.exact_sd@genesInSigPways1)#95




#Mean
# kegg
t0 <- Sys.time() 
exact.test.kegg_mean <- pathVarOneSample(dat.esc, pways=pways.kegg,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 1 mins
write.table(exact.test.kegg_mean@tablePway, file="table_Yan_esc_exact_kegg_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_mean <- pathVarOneSample(dat.esc, pways=pways.reactome,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 18.72654 mins

write.table(exact.test.reactome_mean@tablePway, file="table_Yan_esc_exact_reactome_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.exact_mean=sigPway(exact.test.kegg_mean,0.01)
sig_reactome.exact_mean=sigPway(exact.test.reactome_mean,0.01)

length(sig_kegg.exact_mean@genesInSigPways1)#14
length(sig_reactome.exact_mean@genesInSigPways1)#131

intersect(names(sig_kegg.exact_mean@genesInSigPways1),names(sig_kegg.exact_sd@genesInSigPways1))#8
intersect(names(sig_reactome.exact_mean@genesInSigPways1),names(sig_reactome.exact_sd@genesInSigPways1))#94


save.image("Yan_esc_sd_mean.RData")

