# read in data
dat <- read.table("expression_data_natstructmolbio.txt", sep="\t", row.names=1, header=T)
dat.mat <- t(apply(dat, 1, as.numeric))
dat.mat <- log(dat.mat+1,2)
colnames(dat.mat) <- colnames(dat)

summary(c(dat.mat))
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
#    0.0     0.6     2.4     2.7     4.3    15.6  947821 

# making objects to identify cell/embryo membership (this is just housekeeping)
celltype.id <- colnames(dat)
celltype.id[grep("Oocyte", celltype.id)] <- "oocyte"
celltype.id[grep("Zygote", celltype.id)] <- "zygote"
celltype.id[grep("X2", celltype.id)] <- "twocell"
celltype.id[grep("X4", celltype.id)] <- "fourcell"
celltype.id[grep("X8", celltype.id)] <- "eightcell"
celltype.id[grep("Morulae", celltype.id)] <- "morulae"
celltype.id[grep("blastocyst", celltype.id)] <- "blastocyst"
celltype.id[grep("passage0", celltype.id)] <- "hesc.p0"
celltype.id[grep("passage10", celltype.id)] <- "hesc.p10"

embryo.id <- colnames(dat) 
embryo.id[grep("Oocyte", embryo.id)] <- gsub("Oocyte", "", embryo.id[grep("Oocyte", embryo.id)])
embryo.id[grep("Zygote", embryo.id)] <- gsub("Zygote", "", embryo.id[grep("Zygote", embryo.id)])
embryo.id[grep("X2", embryo.id)] <- gsub("X2.cellembryo", "", embryo.id[grep("X2", embryo.id)])
embryo.id[grep("X4", embryo.id)] <- gsub("X4.cellembryo", "", embryo.id[grep("X4", embryo.id)])
embryo.id[grep("X8", embryo.id)] <- gsub("X8.cellembryo", "", embryo.id[grep("X8", embryo.id)])
embryo.id[grep("Morulae", embryo.id)] <- gsub("Morulae", "", embryo.id[grep("Morulae", embryo.id)])
embryo.id[grep("Lateblastocyst", embryo.id)] <- gsub("Lateblastocyst", "", embryo.id[grep("Lateblastocyst", embryo.id)])
embryo.id[grep("hESCpassage0", embryo.id)] <- gsub("hESCpassage0", "p0", embryo.id[grep("hESCpassage0", embryo.id)])
embryo.id[grep("hESCpassage10", embryo.id)] <- gsub("hESCpassage10", "p10", embryo.id[grep("hESCpassage10", embryo.id)])
embryo.id[grep("Cell", embryo.id)] <- sapply(strsplit(embryo.id[grep("Cell", embryo.id)], ".Cell"), function(x){ x[1] })


# check data quality 
dat.esc=dat.mat[,(embryo.id == "p10") |(embryo.id == "p0")]

dim(dat.esc)#20286    34
qc.esc <- apply(dat.esc, 1, function(x,ct){ sum(x >= ct,na.rm=T) }, ct=1)
sum(qc.esc >= .75*(dim(dat.esc)[2]))		# 6667

dat.esc.filt <- dat.esc[qc.esc >= .75*(dim(dat.esc)[2]),]
dim(dat.esc.filt)					# 6667   34

dat.esc=dat.esc.filt

library(pathVar)

pdf("Yan_esc_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(dat.esc)
dev.off()

save(dat.esc,file="dat_esc.RData")