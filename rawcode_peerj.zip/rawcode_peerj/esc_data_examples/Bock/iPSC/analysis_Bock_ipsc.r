
load("~/real_dataset/Bock/iPSC/dat_ipsc.RData")
library(pathVar)



######MAD

t0 <- Sys.time() 
exact.test.kegg_mad <- pathVarOneSample(dat.ipsc, pways=pways.kegg,test="exact",varStat="mad")
t1 <- Sys.time()
t1-t0
#Time difference of 3 mins
write.table(exact.test.kegg_mad@tablePway, file="table_Bock_ipsc_exact_kegg_MAD.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_mad <- pathVarOneSample(dat.ipsc, pways=pways.reactome,test="exact",varStat="mad")
t1 <- Sys.time()
t1-t0
#Time difference of 18.17605 mins

write.table(exact.test.reactome_mad@tablePway, file="table_Bock_ipsc_exact_reactome_MAD.txt", sep="\t", col.names=T, row.names=F, quote=F)


#sig category exact
sig_kegg.exact_mad=sigPway(exact.test.kegg_mad,0.01)
sig_reactome.exact_mad=sigPway(exact.test.reactome_mad,0.01)
length(sig_kegg.exact_mad@genesInSigPways1)#15
length(sig_reactome.exact_mad@genesInSigPways1)#58

save.image("Bock_ipsc_mad.RData")



#Mean
# kegg
t0 <- Sys.time() 
exact.test.kegg_mean <- pathVarOneSample(dat.ipsc, pways=pways.kegg,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 10.59639 mins
write.table(exact.test.kegg_mean@tablePway, file="table_Bock_ipsc_exact_kegg_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_mean <- pathVarOneSample(dat.ipsc, pways=pways.reactome,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 18.72654 mins

write.table(exact.test.reactome_mean@tablePway, file="table_Bock_ipsc_exact_reactome_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.exact_mean=sigPway(exact.test.kegg_mean,0.01)
sig_reactome.exact_mean=sigPway(exact.test.reactome_mean,0.01)

length(sig_kegg.exact_mean@genesInSigPways1)#22
length(sig_reactome.exact_mean@genesInSigPways1)#149

intersect(names(sig_kegg.exact_mean@genesInSigPways1),names(sig_kegg.exact_mad@genesInSigPways1))#4
intersect(names(sig_reactome.exact_mean@genesInSigPways1),names(sig_reactome.exact_mad@genesInSigPways1))#39


save.image("Bock_ipsc_mad_mean.RData")

