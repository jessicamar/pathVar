
dat <- read.table("Normalized_data_gene_expression_cropped.txt", sep="\t", header=T)

# expression data

exprsMat <- dat[,-(1:7)]
exprsMat <- as.matrix(exprsMat)
rownames(exprsMat) <- as.character(dat[,6])

range(exprsMat)	# 0 to 10, already logged

gsym <- as.character(dat[,7])
gsym.wcomma <- gsym[grep(", ", gsym)]

exprsMat.fin <- exprsMat[-grep(",", gsym),]
rownames(exprsMat.fin) <- gsym[-grep(",", gsym)]

exprsMat.fin <- exprsMat.fin[rownames(exprsMat.fin) != "Unannotated",]

dim(exprsMat.fin)	# 12900 43

# construct sample ids 
samp.id <- colnames(exprsMat.fin) 

length(grep("hES", samp.id))		# 20
length(grep("hiPS", samp.id))		# 12
length(grep("hEB", samp.id))		# 5
length(grep("hFib", samp.id))		# 6

cell.id <- character(length(samp.id))
cell.id[grep("hES", samp.id)] <- "esc"
cell.id[grep("hiPS", samp.id)] <- "ips"
cell.id[grep("hEB", samp.id)] <- "eb"
cell.id[grep("hFib", samp.id)] <- "fibro"

table(cell.id)

#   eb   esc fibro   ips 
#    5    20     6    12

# background steps 

dat.ipsc=exprsMat.fin[,cell.id == "ips"]

qc.ipsc <- apply(dat.ipsc, 1, function(x,ct){ sum(x >= ct) }, ct=1)


sum(qc.ipsc >= .75*(dim(dat.ipsc)[2]))		# 7646


dat.ipsc.filt <- dat.ipsc[qc.ipsc >= .75*(dim(dat.ipsc)[2]),]
dim(dat.ipsc.filt)					# 7646x12



# 1 sample 

# esc

uniquegenenames=unique(row.names(dat.ipsc.filt))
gene=matrix(rep(0,length(uniquegenenames)*12),nrow=length(uniquegenenames),ncol=12)
for(i in 1:length(uniquegenenames)){
	print(i)
	if(length(which(row.names(dat.ipsc.filt)==uniquegenenames[i]))>1){
	gene[i,]=apply(dat.ipsc.filt[which(row.names(dat.ipsc.filt)==uniquegenenames[i]),],2,function(x) mean(x))}else{gene[i,]=dat.ipsc.filt[which(row.names(dat.ipsc.filt)==uniquegenenames[i]),]}
}
row.names(gene)=uniquegenenames
colnames(gene)=colnames(dat.ipsc.filt)
dat.ipsc=gene



library(pathVar)

pdf("Bock_ipsc_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(dat.ipsc)
dev.off()

save(dat.ipsc,file="dat_ipsc.RData")