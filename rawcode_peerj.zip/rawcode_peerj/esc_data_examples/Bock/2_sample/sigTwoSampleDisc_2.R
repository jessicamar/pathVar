sigTwoSamplesDisc_2 <- function(pvalue_results, pvalue) {
    xtab <- pvalue_results@tablePway
    olap.pways1 <- pvalue_results@genesInPway1
    olap.pways2 <- pvalue_results@genesInPway2
    pwayCounts1 <- pvalue_results@pwayCounts1
    pwayCounts2 <- pvalue_results@pwayCounts2
    if (length(rownames(xtab[APval < pvalue, ])) < 1) {
        warning("There are no significant pathways. Quitting significant_category function and returning empty object")
        sig <- new("significantPathway3", genesInSigPways1=list(), genesInSigPways2=list(), sigCatPerPway=list(), thresPValue=numeric())
        return(sig)
    }
    # PathName that were significant in xtab.
    significant <- xtab[APval < pvalue, PwayName]
    # The list of table with the number of genes in each cluster from the significant pathways
    sigPwayCounts1 <- pwayCounts1[significant]
    sigPwayCounts2 <- pwayCounts2[significant]
    genes <- vector("list", length(significant))
    category <- vector("list", length(significant))
    names(genes) <- significant
    names(category) <- significant
    # results contain the p-value for each category in each pathway computed with the binomial
    # test
    f <- file()
    sink(file = f)
    results <- sapply(significant, function(x) apply(rbind(sigPwayCounts2[x][[1]], sigPwayCounts1[x][[1]]/sum(sigPwayCounts1[x][[1]])), 
        2, function(y) multinomial.test(c(y[1], sum(sigPwayCounts2[x][[1]]) - y[1]), prob = c(y[2], 
            1 - y[2]))$p.value))
    sink()
    close(f)
    row.names(results) <- NULL
    # For each significant pathway we look which category(ies) is are significant and the genes belonging to this(ese) category(ies). If no category is significant we will write 0 in the category and the gene names.
    genes1 <- olap.pways1[significant]
    genes2 <- olap.pways2[significant]
    sigCat <- which(apply(results, 2, function(x) sum(x < pvalue)) > 0)
    if(length(significant<2)){
    	numOfSigCat <- length(which(results[, sigCat] < pvalue))
    	category[sigCat] <- which(results[, sigCat] < pvalue)
    	
    }else{
    	numOfSigCat <- apply(results[, sigCat], 2, function(x) length(which(x < pvalue)))
    	
    	if (length(which(numOfSigCat == 3)) == length(sigCat)) {
        	category[sigCat] <- lapply(as.list(data.frame(apply(results[, sigCat], 2, function(x) which(x < 
            pvalue)))), function(x) unique(x))
    	} else {
        category[sigCat] <- apply(results[, sigCat], 2, function(x) which(x < pvalue))
    	}
    }
    noSigCat <- which(apply(results, 2, function(x) sum(x < pvalue)) < 1)
    if (length(noSigCat) > 0) {
        category[noSigCat] <- 0
    }
    sig <- new("significantPathway3", genesInSigPways1=genes1, genesInSigPways2=genes2, sigCatPerPway=category, thresPValue=pvalue)
    return(sig)
}
