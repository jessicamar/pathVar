load("~/real_dataset/Bock/2 samples/dat.esc_ips.RData")

groups=as.factor(c(rep(1,20),rep(2,12)))
library(pathVar)





BockKeggDiscMAD=pathVarTwoSamplesDisc(dat.esc_ips, pways.kegg,test="exact",groups=groups,varStat="mad")
write.table(BockKeggDiscMAD@tablePway, file="table_Bock_kegg_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.disc_mad=sigPway(BockKeggDiscMAD,0.01)
length(sig_kegg.disc_mad@genesInSigPways1)#8



BockReactomeDiscMAD=pathVarTwoSamplesDisc(dat.esc_ips, pways.reactome,test="exact",groups=groups,varStat="mad")
write.table(BockReactomeDiscMAD@tablePway, file="table_Bock_reactome_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.disc_mad=sigPway(BockReactomeDiscMAD,0.01)
length(sig_reactome.disc_mad@genesInSigPways1)#39





#MEan

BockKeggDisc_mean=pathVarTwoSamplesDisc(dat.esc_ips, pways.kegg,test="exact",groups=groups,varStat="mean")
write.table(BockKeggDisc_mean@tablePway, file="table_Bock_kegg_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

BockReactomeDisc_mean=pathVarTwoSamplesDisc(dat.esc_ips, pways.reactome,test="exact",groups=groups,varStat="mean")
write.table(BockReactomeDisc_mean@tablePway, file="table_Bock_reactome_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_kegg.disc_mean= sigTwoSamplesDisc_2(BockKeggDisc_mean,0.01)
sig_reactome.disc_mean=sigPway(BockReactomeDisc_mean,0.01)

length(sig_kegg.disc_mean@genesInSigPways1)#1
length(sig_reactome.disc_mean@genesInSigPways1)#3

intersect(names(sig_kegg.disc_mean@genesInSigPways1),names(sig_kegg.disc_mad@genesInSigPways1))#0
intersect(names(sig_reactome.disc_mean@genesInSigPways1),names(sig_reactome.disc_mad@genesInSigPways1))#1


save.image("Bock_mad_mean.RData")

dat.esc=dat.esc_ips[,1:20]
dat.ips=dat.esc_ips[,21:32]

vs <- apply(dat.esc_ips, 1, function(x) mad(x, na.rm = TRUE))
var_1 <- BockReactomeDiscMAD@var1
var_2 <- BockReactomeDiscMAD@var2

cut <- quantile(vs, probs = c(1/3, 2/3))
    mixesc <- rep(NA, dim(dat.esc)[1])
    mixesc[var_1 <= cut[1]] <- 1
    mixesc[var_1 <= cut[2] & var_1 > cut[1]] <- 2
    mixesc[var_1 > cut[2]] <- 3
    names(mixesc) <- row.names(dat.esc)
    # In which cluster each gene is
    mixips <- rep(NA, dim(dat.ips)[1])
    mixips[var_2 <= cut[1]] <- 1
    mixips[var_2 <= cut[2] & var_2 > cut[1]] <- 2
    mixips[var_2 > cut[2]] <- 3
    names(mixips) <- row.names(dat.ips)

table(mixesc)
#   1    2    3 
#3067 2308 2179  

table(mixips)
#   1    2    3 
#2949 2210 2395  

pathesc <- as.data.frame(table(mixesc))
colnames(pathesc) <- c("Cluster", "Number_of_genes")

pathips <- as.data.frame(table(mixips))
colnames(pathips) <- c("Cluster", "Number_of_genes")
 plotPathesc <- ggplot(pathesc, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("hESC") + xlab("") + ylim(0, 3067)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
 
  plotPathips <- ggplot(pathips, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("iPSC") + xlab("") + ylim(0, 3067)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
  pdf("escVSipsCounts.pdf",width=10,height=7)
  grid.arrange(arrangeGrob(plotPathesc, plotPathips, nrow = 1))
  dev.off()

  