
dat <- read.table("Normalized_data_gene_expression_cropped.txt", sep="\t", header=T)

# expression data

exprsMat <- dat[,-(1:7)]
exprsMat <- as.matrix(exprsMat)
rownames(exprsMat) <- as.character(dat[,6])

range(exprsMat)	# 0 to 10, already logged

gsym <- as.character(dat[,7])
gsym.wcomma <- gsym[grep(", ", gsym)]

exprsMat.fin <- exprsMat[-grep(",", gsym),]
rownames(exprsMat.fin) <- gsym[-grep(",", gsym)]

exprsMat.fin <- exprsMat.fin[rownames(exprsMat.fin) != "Unannotated",]

dim(exprsMat.fin)	# 12900 43

# construct sample ids 
samp.id <- colnames(exprsMat.fin) 

length(grep("hES", samp.id))		# 20
length(grep("hiPS", samp.id))		# 12
length(grep("hEB", samp.id))		# 5
length(grep("hFib", samp.id))		# 6

cell.id <- character(length(samp.id))
cell.id[grep("hES", samp.id)] <- "esc"
cell.id[grep("hiPS", samp.id)] <- "ips"
cell.id[grep("hEB", samp.id)] <- "eb"
cell.id[grep("hFib", samp.id)] <- "fibro"

table(cell.id)

#   eb   esc fibro   ips 
#    5    20     6    12

# background steps 


qc.esc <- apply(exprsMat.fin[,cell.id == "esc"], 1, function(x,ct){ sum(x >= ct) }, ct=1)
sum(qc.esc >= .75*sum(cell.id == "esc"))		# 7632
qc.ips <- apply(exprsMat.fin[,cell.id == "ips"], 1, function(x,ct){ sum(x >= ct) }, ct=1)
sum(qc.ips >= .75*sum(cell.id == "ips"))# 7646

sum((qc.ips >= .75*sum(cell.id == "ips"))&(qc.esc >= .75*sum(cell.id == "esc")))	#7564	

dat.esc_ips.filt=exprsMat.fin[(qc.ips >= .75*sum(cell.id == "ips"))&(qc.esc >= .75*sum(cell.id == "esc")),cell.id == "esc"|cell.id == "ips"] 

dim(dat.esc_ips.filt)					#7564x32



# 1 sample 

# esc_ips

uniquegenenames=unique(row.names(dat.esc_ips.filt))
gene=matrix(rep(0,length(uniquegenenames)*32),nrow=length(uniquegenenames),ncol=32)
for(i in 1:length(uniquegenenames)){
	print(i)
	if(length(which(row.names(dat.esc_ips.filt)==uniquegenenames[i]))>1){
	gene[i,]=apply(dat.esc_ips.filt[which(row.names(dat.esc_ips.filt)==uniquegenenames[i]),],2,function(x) mean(x))}else{gene[i,]=dat.esc_ips.filt[which(row.names(dat.esc_ips.filt)==uniquegenenames[i]),]}
}
row.names(gene)=uniquegenenames
colnames(gene)=colnames(dat.esc_ips.filt)
dat.esc_ips=gene



library(pathVar)
diagnosticsVarPlots_2 <- function(dat.mat1,dat.mat2) {
    # Compute the sd, mean,cv and mad for each gene
    dat.sd1 <- apply(dat.mat1, 1, sd, na.rm = TRUE)
    dat.avg1 <- rowMeans(dat.mat1, na.rm = TRUE)
    dat.cv1 <- apply(dat.mat1, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad1 <- apply(dat.mat1, 1, mad, na.rm = TRUE)

    dat.sd2 <- apply(dat.mat2, 1, sd, na.rm = TRUE)
    dat.avg2 <- rowMeans(dat.mat2, na.rm = TRUE)
    dat.cv2 <- apply(dat.mat2, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad2 <- apply(dat.mat2, 1, mad, na.rm = TRUE)

    data.sd <- data.frame(standDev = c(dat.sd1,dat.sd2), avg = c(dat.avg1,dat.avg2))
    data.mad <- data.frame(medAbsDev = c(dat.mad1,dat.mad2), avg = c(dat.avg1,dat.avg2))
    data.cv <- data.frame(cv = c(dat.cv1,dat.cv2), avg = c(dat.avg1,dat.avg2))
    # Plot the mean vs the standard deviation and give the correlation between both in the title.
    plotSD <- ggplot(data.sd, aes(x = avg, y = standDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Standard Deviation (SD)") + ggtitle(paste(c("Standard Deviation [ R=", round(cor(data.sd$standDev, 
        data.sd$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the median absolute deviation and give the correlation between both in the title.
    plotMAD <- ggplot(data.mad, aes(x = avg, y = medAbsDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Median Absolute Deviation (MAD)") + ggtitle(paste(c("Median Absolute Deviation [ R=", 
        round(cor(data.mad$medAbsDev, 
        data.mad$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the coefficient of variation and give the correlation between both in the title.
    plotCV <- ggplot(data.cv, aes(x = avg, y = cv)) + geom_point(colour = "grey60") + stat_smooth(method = loess) + 
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), 
            axis.line = element_line(colour = "black")) + xlab("Average") + ylab("Coefficient of Variation (CV)") + 
        ggtitle(paste(c("Coefficient of Variation [ R=", round(cor(data.cv$cv, 
        data.cv$avg), 3), "]"), 
            collapse = " "))
    grid.arrange(arrangeGrob(plotSD, plotMAD, plotCV, nrow = 1))
}

dat.esc=dat.esc_ips[,1:20]
dat.ips=dat.esc_ips[,21:32]
pdf("Bock_esc_ips_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots_2(dat.esc,dat.ips)
dev.off()


save(dat.esc_ips,file="dat.esc_ips.RData")