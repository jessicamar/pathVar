


library(pwr)
 w=seq(0.05,0.95,by=0.05)
 p=matrix(rep(0,200*19),nrow=19,ncol=200)
 for(i in 1:19){
 	
 for(n in 1:200){
	
	
	 p[i,n]=pwr.chisq.test(w[i],df=2,N=n,sig.level=0.05)$power
 }

}


color=rainbow(19)
 plot(1:200,p[1,],ylim=c(-0.2,1),col=color[1],xlab="g",ylab="Power",main="Chi-squared",type="l")
 for(i in 2:19){
 lines(1:200,p[i,],col=color[i])
}
abline(h=0.8,col="red",lwd=2)
 leg.txt=seq(0.05,0.95,by=0.05)
 legend("bottom",pch=1,col=color,legend=leg.txt,title="Effect size w",horiz=T,cex=0.45)
 
 tiff("power_all.tiff",width=70,height=70,units="mm",res=300,compression="lzw")
  plot(1:200,p[1,],ylim=c(-0.05,1),col=color[1],xlab="Number of genes",ylab="Power",main="Chi-squared",type="l",cex=0.1)
 for(i in 2:19){
 lines(1:200,p[i,],col=color[i])
}
abline(h=0.8,col="red",lwd=2)
 leg.txt=seq(0.05,0.95,by=0.05)
 legend("bottom",pch=1,col=color,legend=leg.txt,title="Effect size w",horiz=T,cex=0.1)
dev.off()

power=NULL
genes=NULL
Effect_size=NULL
for(i in 1:19){
	print(i)
power=c(power,p[i,])
genes=c(genes,1:200)
Effect_size=c(Effect_size,rep(as.character(i),200))
}
power=cbind(genes,power)

 power=as.data.frame(power)

 # par(mfrow=c(1,2))
 # plot(1:200,power_1[,2],ylim=c(-0.2,1),col="blue",xlab="Number of genes",ylab="Power",main="Chi-squared",type="l",lwd=2)

leg.txt=seq(0.05,0.95,by=0.05)
plot_power=ggplot(power,aes(x=genes,y=power,group=Effect_size,colour=Effect_size)) +geom_line(size=0.5)+xlab("Number of genes")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_color_manual(values=rainbow(19),labels = leg.txt)+theme_bw(base_size = 4)+theme(legend.position="bottom",legend.key.size=unit(0.1,"cm"))+ggtitle("Chi-squared")+ scale_y_continuous(breaks=seq(0,1,0.2),limits=c(0,1))+guides(color=guide_legend(nrow=2))#+ geom_hline(y=0.8,colour="red")

tiff("power_all.tiff",width=70,height=70,units="mm",res=300,compression="lzw")
plot_power
dev.off()



 
 #Example one side
 p0=c(0.25,0.5,0.25)
 p1=c(0.35,0.4,0.25)
 ES.w1(p0,p1)
 power_1=rep(0,200)
 
 for(n in 1:200){
	
	
	 power_1[n]=pwr.chisq.test( ES.w1(p0,p1),df=2,N=n,sig.level=0.05)$power
 }

 
 
 plot(1:200,power_1,ylim=c(-0.2,1),col="blue",xlab="Number of genes",ylab="Power",main="Chi-squared",type="l",lwd=2)

 
 
# 0.244949 which is the same than sqrt(6)*0.1
 #Example two sides
 p0=c(0.25,0.5,0.25)
 p1=c(0.3,0.4,0.3)
 ES.w1(p0,p1)
  power_2=rep(0,200)
 
 for(n in 1:200){
	
	
	 power_2[n]=pwr.chisq.test( ES.w1(p0,p1),df=2,N=n,sig.level=0.05)$power
 }

# 0.2 which is the same than sqrt(4)*0.1

lines(1:200,power_2,ylim=c(-0.2,1),col="darkgreen",lwd=2)
abline(h=0.8,col="red")

 leg.txt=c("p1=(0.35,0.4,0.25)","p1=(0.3,0.4,0.3)")
 legend(locator(1),pch=1,col=c("blue","darkgreen"),legend=leg.txt,title="p0=(0.25,0.5,0.25)",horiz=T,cex=0.8)
 
 
 
 library(ggplot2)
 library(gridExtra)

Group=c("Group 1","Group 2","Group 3")
 #gene TOP1MT 57 loci
p0=c(0.25,0.5,0.25)
 p1=c(0.35,0.4,0.25)
 p2=c(0.3,0.4,0.3)


    
p0=cbind(Group,p0)
p0=as.data.frame(p0)
p0[,2]=as.numeric(as.character(p1[,0]))
#clust_LAML$distr<-factor(clust_LAML$distr,levels=rev(distr))
colnames(p0)=c("Group","value")
color=c("grey","grey","grey")
d=ggplot(p0,aes(x=Group,y=value,fill=Group))
plot1=d+geom_bar(stat="identity",color="black")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_fill_manual(values = color)+ylab("Probability")+theme_bw(base_size = 6)+theme(legend.position="none")+ggtitle('Reference p0=(0.25,0.5,0.25)') +xlab("")
    
    plot(plot1)
    
p1=cbind(Group,p1)
p1=as.data.frame(p1)
p1[,2]=as.numeric(as.character(p1[,2]))
#clust_LAML$distr<-factor(clust_LAML$distr,levels=rev(distr))
colnames(p1)=c("Group","value")
color=c("steelblue1","steelblue1","steelblue1")
d=ggplot(p1,aes(x=Group,y=value,fill=Group))
plot2=d+geom_bar(stat="identity",color="black")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_fill_manual(values = color)+ylab("Probability")+theme_bw(base_size = 6)+theme(legend.position="none")+ggtitle('First case p1=(0.35,0.4,0.25)') +xlab("")+ylim(0,0.5)
    
    plot(plot2)
    
    
    p2=cbind(Group,p2)
p2=as.data.frame(p2)
p2[,2]=as.numeric(as.character(p2[,2]))
#clust_LAML$distr<-factor(clust_LAML$distr,levels=rev(distr))
colnames(p2)=c("Group","value")
color=c("steelblue1","steelblue1","steelblue1")
d=ggplot(p2,aes(x=Group,y=value,fill=Group))
plot3=d+geom_bar(stat="identity",color="black")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_fill_manual(values = color)+ylab("Number of genes")+theme_bw(base_size = 6)+theme(legend.position="none")+ggtitle('Second case p2=(0.3,0.4,0.3)') +xlab("")+ylim(0,0.5)
    
    plot(plot3)




    
g2=arrangeGrob(plot1,plot2,plot3,nrow = 1)

#Example one side
 p0=c(0.25,0.5,0.25)
 p1=c(0.35,0.4,0.25)
 ES.w1(p0,p1)
 power_1=rep(0,200)
 
 for(n in 1:200){
	
	
	 power_1[n]=pwr.chisq.test( ES.w1(p0,p1),df=2,N=n,sig.level=0.05)$power
 }
 
  p0=c(0.25,0.5,0.25)
 p1=c(0.3,0.4,0.3)
 ES.w1(p0,p1)
  power_2=rep(0,200)
 
 for(n in 1:200){
	
	
	 power_2[n]=pwr.chisq.test( ES.w1(p0,p1),df=2,N=n,sig.level=0.05)$power
 }
 
power=c(power_1,power_2)
genes=c(1:200,1:200)
Case=c(rep("1",200),rep("2",200))
 power=cbind(genes,power)

 power=as.data.frame(power)

 # par(mfrow=c(1,2))
 # plot(1:200,power_1[,2],ylim=c(-0.2,1),col="blue",xlab="Number of genes",ylab="Power",main="Chi-squared",type="l",lwd=2)


plot4=ggplot(power,aes(x=genes,y=power,group=Case,colour=Case)) +geom_line(size=1)+xlab("Number of genes")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_color_manual(values=c("#000099","#00FFCC"),labels = c("1: p1=(0.35,0.4,0.25); w=0.24","2: p2=(0.3,0.4,0.3); w=0.2"))+theme_bw(base_size = 6)+theme(legend.position="bottom",legend.key.size=unit(0.2,"cm"))+ geom_hline(y=0.8,colour="red")+ scale_y_continuous(breaks=seq(0,1,0.2),limits=c(0,1))+ggtitle("Comparing p0 with p1 and p2")



 
 


tiff("example_2.tiff",width=140,height=140,units="mm",res=300,compression="lzw")
g=grid.arrange(arrangeGrob(plot1,plot2,plot3,plot4,nrow = 2))
dev.off()





