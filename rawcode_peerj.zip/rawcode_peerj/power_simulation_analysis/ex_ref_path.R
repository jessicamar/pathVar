
    library(ggplot2)
    library(gridExtra)

    ref=cbind(c("Low", "Medium","High"),c(2500,5000,2500))
    ref=as.data.frame(ref)
    ref[,2]=as.numeric(as.character(ref[,2]))
        colnames(ref)=c("Cluster","Number_of_genes")
        ref$Cluster=factor(ref$Cluster,levels=c("Low", "Medium","High"))


    d=ggplot(ref,aes(x=Cluster,y=Number_of_genes,fill=Cluster))
    plot_ref=d+geom_bar(stat="identity",color="black",fill="grey")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ylab("Number of genes")+theme_bw(base_size = 12)+theme(legend.position="none")+ggtitle("Reference") +xlab("")+ylim(c(0,5600))
    
    
   mp="Pathway 1"
   
           obs.val=c(10,55,35)
        path=cbind(c("Low","Medium","High"),obs.val)
        path=as.data.frame(path)
        path[,2]=as.numeric(as.character(path[,2]))

        colnames(path)=c("Cluster","Number_of_genes")
         path$Cluster=factor(path$Cluster,levels=c("Low", "Medium","High"))

        d=ggplot(path,aes(x=Cluster,y=Number_of_genes,fill=Cluster))
     
                plot1=d+geom_bar(stat="identity",color="black",fill="steelblue1")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                panel.background = element_blank(), axis.line = element_line(colour = "black"))+ylab("Number of genes")+theme_bw(base_size = 12)+theme(legend.position="none")+ggtitle(mp) +xlab("")+ylim(c(0,56))
                #+annotate("text",x=c(1,3),y=path[c(1,3)+0.1,2],label=rep("*",2),color="red",size=15) 
  
  
   g=grid.arrange(arrangeGrob(plot_ref,plot1,nrow=1)) 
   
   pdf("ex_ref_path.pdf",g,width=10,height=7)
g=grid.arrange(arrangeGrob(plot_ref,plot1,nrow=1)) 
dev.off()


    d=ggplot(ref,aes(x=Cluster,y=Number_of_genes,fill=Cluster))
    plot_ref=d+geom_bar(stat="identity",color="black",fill="grey")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ylab("Number of genes")+theme_bw(base_size = 8)+theme(legend.position="none")+ggtitle("Reference") +xlab("")+ylim(c(0,5600))

  d=ggplot(path,aes(x=Cluster,y=Number_of_genes,fill=Cluster))
     
                plot1=d+geom_bar(stat="identity",color="black",fill="steelblue1")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                panel.background = element_blank(), axis.line = element_line(colour = "black"))+ylab("Number of genes")+theme_bw(base_size = 8)+theme(legend.position="none")+ggtitle(mp) +xlab("")+ylim(c(0,56))
                #+annotate("text",x=c(1,3),y=path[c(1,3)+0.1,2],label=rep("*",2),color="red",size=15) 
g=arrangeGrob(plot_ref,plot1,nrow=1)
ggsave("ex_ref_path.tiff",g,width=85,height=55,units="mm",compression="lzw")

