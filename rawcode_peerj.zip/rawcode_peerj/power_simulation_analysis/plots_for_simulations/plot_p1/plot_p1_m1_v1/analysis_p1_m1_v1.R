

simulation<-function(g,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3){
	
	sim_data=NULL
for(i in 1:(g*p1)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean1,sd=sigma1))
	
}

for(i in 1:(g*p2)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean2,sd=sigma2))
	
}
for(i in 1:(g*p3)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean3,sd=sigma3))
	
}


genes=NULL
for(i in 1:g){
	genes=c(genes,paste("G",i,sep=""))
	
}
samples=NULL
for(i in 1:n){
	samples=c(samples,paste("S",i,sep=""))
	
}

row.names(sim_data)=genes
colnames(sim_data)=samples


return(sim_data)
}



	
library(mclust)	
BIC_100<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_sd=apply(sim1,1,function(x) sd(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_sd,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_sd,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_sd,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 BIC_100_mad<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_mad=apply(sim1,1,function(x) mad(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_mad,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_mad,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_mad,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 #cv
covar<-function(x){
	cv=sd(x)/mean(x)
	return(cv)
}


BIC_100_cv<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_cv=apply(sim1,1,function(x) covar(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_cv,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_cv,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_cv,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 


	 
essai=BIC_100(10000,30,0.25,0.5,0.25,9,9,9,1,2,3,5)
#best is 3V
par(mfrow=c(2,2))
boxplot(cbind(essai$V_bic,essai$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai$good[,1],5000-essai$good[,2],2500-essai$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 3
plot(1:100,essai$V_bic[,2],ylab="BIC",xlab="Simulation number",ylim=c(-18900,-18000))
points(1:100,essai$V_bic[,3],col="red")
points(1:100,essai$V_bic[,4],col="blue")
leg.txt=c("3","4","5")
legend(locator(1),pch=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")
#best is 3
plot(density(essai$V_bic[,2]),xlab="BIC",main="")
lines(density(essai$V_bic[,3]),col="red")
lines(density(essai$V_bic[,4]),col="blue")
legend(locator(1),lty=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")

#3 components always better that 4 and 5
sum(essai$V_bic[,2]>essai$V_bic[,3])#100
sum(essai$V_bic[,2]>essai$V_bic[,4])#100

 sim1=simulation(10000,30,0.25,0.5,0.25,9,9,9,1,2,3)
 sim_sd_1=apply(sim1,1,function(x) sd(x))
 e1=Mclust(sim_sd_1)
 summary(e1)#best 3 V
mis_sd=rowSums(mis)
mean(mis_sd)#480.08
sd(mis_sd)#26.027
 
	

essai_mad=BIC_100_mad(10000,30,0.25,0.5,0.25,9,9,9,1,2,3,5)	

par(mfrow=c(2,2))
boxplot(cbind(essai_mad$V_bic,essai_mad$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_mad$good[,1],5000-essai_mad$good[,2],2500-essai_mad$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 3
plot(1:100,essai_mad$V_bic[,2],ylab="BIC",xlab="Simulation number",ylim=c(-23200,-22200))
points(1:100,essai_mad$V_bic[,3],col="red")
points(1:100,essai_mad$V_bic[,4],col="blue")
leg.txt=c("3","4","5")
legend(locator(1),pch=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")

#best is 3
plot(density(essai_mad$V_bic[,2]),xlab="BIC",main="")
lines(density(essai_mad$V_bic[,3]),col="red")
lines(density(essai_mad$V_bic[,4]),col="blue")
legend(locator(1),lty=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")

#3 components always better that 4 and 5
sum(essai_mad$V_bic[,2]>essai_mad$V_bic[,3])#100
sum(essai_mad$V_bic[,2]>essai_mad$V_bic[,4])#100

mis_mad=rowSums(mis)
mean(mis_mad)#1661.37
sd(mis_mad)#45.39




 sim_mad=apply(sim1,1,function(x) mad(x))
 e1_mad=Mclust(sim_mad)
 summary(e1_mad)#best 3 V





#best is 3







essai_cv=BIC_100_cv(10000,30,0.25,0.5,0.25,9,9,9,1,2,3,5)	
 par(mfrow=c(2,2))
boxplot(cbind(essai_cv$V_bic,essai_cv$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_cv$good[,1],5000-essai_cv$good[,2],2500-essai_cv$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")


#best is 3
plot(1:100,essai_cv$V_bic[,2],ylab="BIC",xlab="Simulation number",ylim=c(24400,25500))
points(1:100,essai_cv$V_bic[,3],col="red")
points(1:100,essai_cv$V_bic[,4],col="blue")
leg.txt=c("3","4","5")
legend(locator(1),pch=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")
#best is 3
plot(density(essai_cv$V_bic[,2]),xlab="BIC",main="")
lines(density(essai_cv$V_bic[,3]),col="red")
lines(density(essai_cv$V_bic[,4]),col="blue")
legend(locator(1),lty=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")

#3 components always better that 4 and 5
sum(essai_cv$V_bic[,2]>essai_cv$V_bic[,3])#100
sum(essai_cv$V_bic[,2]>essai_cv$V_bic[,4])#100

 sim_cv=apply(sim1,1,function(x) covar(x))
 e1_cv=Mclust(sim_cv)
 summary(e1_cv)#best 3 V
mis_cv=rowSums(mis)
mean(mis_cv)#669.99
sd(mis_cv)#53.283


 
save.image("sim_p1_m1_v1.RData")

