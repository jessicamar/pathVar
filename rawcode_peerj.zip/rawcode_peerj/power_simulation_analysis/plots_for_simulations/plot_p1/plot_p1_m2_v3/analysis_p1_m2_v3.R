 simulation<-function(g,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3){
	
	sim_data=NULL
for(i in 1:(g*p1)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean1,sd=sigma1))
	
}

for(i in 1:(g*p2)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean2,sd=sigma2))
	
}
for(i in 1:(g*p3)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean3,sd=sigma3))
	
}


genes=NULL
for(i in 1:g){
	genes=c(genes,paste("G",i,sep=""))
	
}
samples=NULL
for(i in 1:n){
	samples=c(samples,paste("S",i,sep=""))
	
}

row.names(sim_data)=genes
colnames(sim_data)=samples


return(sim_data)
}



 
library(mclust)	
BIC_100<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_sd=apply(sim1,1,function(x) sd(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_sd,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_sd,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_sd,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
BIC_100_mad<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_mad=apply(sim1,1,function(x) mad(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_mad,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_mad,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_mad,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }

 covar<-function(x){
	cv=sd(x)/mean(x)
	return(cv)
}

BIC_100_cv<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_cv=apply(sim1,1,function(x) covar(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_cv,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_cv,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_cv,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }




 
 essai_dm_2=BIC_100(10000,30,0.25,0.5,0.25,3,7,10,1,1.2,1.4,5)#best is 3V
par(mfrow=c(2,2))
boxplot(cbind(essai_dm_2$V_bic,essai_dm_2$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_dm_2$good[,1],5000-essai_dm_2$good[,2],2500-essai_dm_2$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 2
plot(1:100,essai_dm_2$V_bic[,1],ylab="BIC",xlab="Simulation number",ylim=c(2400,3700),col="green")
points(1:100,essai_dm_2$V_bic[,2],col="black")
points(1:100,essai_dm_2$V_bic[,3],col="red")
leg.txt=c("2","3","4")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")
#best is 3
plot(density(essai_dm_2$V_bic[,1]),xlab="BIC",main="",col="green")
lines(density(essai_dm_2$V_bic[,2]),col="black")
lines(density(essai_dm_2$V_bic[,3]),col="red")
legend(locator(1),lty=1,col=c("green","black","red"),legend=leg.txt,title="# of components")

#3 components not better than 2
sum(essai_dm_2$V_bic[,2]>essai_dm_2$V_bic[,1])#26
sum(essai_dm_2$V_bic[,2]>essai_dm_2$V_bic[,3])#100

best_2=apply(cbind(essai_dm_2$V_bic,essai_dm_2$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
# 1  2  5  6 
#28  2  1 69 

sim1_dm=simulation(10000,30,0.25,0.5,0.25,3,7,10,1,1.2,1.4)
 sim_dm_sd_1=apply(sim1_dm,1,function(x) sd(x))
 e1_dm=Mclust(sim_dm_sd_1)
 summary(e1_dm)#best 3 E
  mis_sd=rowSums(mis)
mean(mis_sd)#4056.89
sd(mis_sd)#91.13





	


 essai_mad_dm_2=BIC_100_mad(10000,30,0.25,0.5,0.25,3,7,10,1,1.2,1.4,5)	

par(mfrow=c(2,2))
boxplot(cbind(essai_mad_dm_2$V_bic,essai_mad_dm_2$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_mad_dm_2$good[,1],5000-essai_mad_dm_2$good[,2],2500-essai_mad_dm_2$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 3
plot(1:100,essai_mad_dm_2$V_bic[,1],ylab="BIC",xlab="Simulation number",ylim=c(-3400,-2100),col="green")
points(1:100,essai_mad_dm_2$V_bic[,2],col="black")
points(1:100,essai_mad_dm_2$V_bic[,3],col="red")
leg.txt=c("2","3","4")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")

#best is 3
plot(density(essai_mad_dm_2$V_bic[,1]),xlab="BIC",main="",col="green")
lines(density(essai_mad_dm_2$V_bic[,2]),col="black")
lines(density(essai_mad_dm_2$V_bic[,3]),col= "red")
legend(locator(1),lty=1,col=c("green","black","red"),legend=leg.txt,title="# of components")

#3 components not better that 2
sum(essai_mad_dm_2$V_bic[,2]>essai_mad_dm_2$V_bic[,1])#72
sum(essai_mad_dm_2$V_bic[,2]>essai_mad_dm_2$V_bic[,3])#100
best_2=apply(cbind(essai_mad_dm_2$V_bic,essai_mad_dm_2$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
# 1  2  6  7 
#28 70  1  1 

 sim_mad_dm=apply(sim1_dm,1,function(x) mad(x))
 e1_mad_dm=Mclust(sim_mad_dm)
 summary(e1_mad_dm)#best 3 V

 mis_mad=rowSums(mis)
mean(mis_mad)#4920.9
sd(mis_mad)#92.11





essai_cv_dm_2=BIC_100_cv(10000,30,0.25,0.5,0.25,3,7,10,1,1.2,1.4,5)
 par(mfrow=c(2,2))
boxplot(cbind(essai_cv_dm_2$V_bic,essai_cv_dm_2$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_cv_dm_2$good[,1],5000-essai_cv_dm_2$good[,2],2500-essai_cv_dm_2$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")


#best is 3
plot(1:100,essai_cv_dm_2$V_bic[,1],ylab="BIC",xlab="Simulation number",col="green",ylim=c(30000,31500))
points(1:100,essai_cv_dm_2$V_bic[,2],col="black")
points(1:100,essai_cv_dm_2$V_bic[,3],col="red")
leg.txt=c("2","3","4")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")
#best is 2
plot(density(essai_cv_dm_2$V_bic[,1]),xlab="BIC",main="",col="green")
lines(density(essai_cv_dm_2$V_bic[,2]),col="black")
lines(density(essai_cv_dm_2$V_bic[,3]),col="red")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")

#3 components always better than 2
sum(essai_cv_dm_2$V_bic[,2]>essai_cv_dm_2$V_bic[,1])#100
sum(essai_cv_dm_2$V_bic[,2]>essai_cv_dm_2$V_bic[,3])#100
best_2=apply(cbind(essai_cv_dm_2$V_bic,essai_cv_dm_2$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
#  2 
#100


 sim_cv_dm=apply(sim1_dm,1,function(x) covar(x))
 e1_cv_dm=Mclust(sim_cv_dm)
 summary(e1_cv_dm)#best 3 V
 mis_cv=rowSums(mis)
mean(mis_cv)#6495.24
sd(mis_cv)#52.02


save.image("sim_p1_m2_v3.RData")





