

simulation<-function(g,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3){
	
	sim_data=NULL
for(i in 1:(g*p1)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean1,sd=sigma1))
	
}

for(i in 1:(g*p2)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean2,sd=sigma2))
	
}
for(i in 1:(g*p3)){
	
	sim_data=rbind(sim_data,rnorm(30,mean=mean3,sd=sigma3))
	
}


genes=NULL
for(i in 1:g){
	genes=c(genes,paste("G",i,sep=""))
	
}
samples=NULL
for(i in 1:n){
	samples=c(samples,paste("S",i,sep=""))
	
}

row.names(sim_data)=genes
colnames(sim_data)=samples


return(sim_data)
}



	
library(mclust)	
BIC_100<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_sd=apply(sim1,1,function(x) sd(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_sd,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_sd,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_sd,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 BIC_100_mad<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_mad=apply(sim1,1,function(x) mad(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_mad,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_mad,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_mad,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 #cv
covar<-function(x){
	cv=sd(x)/mean(x)
	return(cv)
}


BIC_100_cv<-function(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3,G){
	V_bic=NULL
	E_bic=NULL
	m=NULL
	good=NULL
	for(i in 1:100){
	 print(i)
	 sim1=simulation(gene,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3)
	 genes=row.names(sim1)
	 sim_cv=apply(sim1,1,function(x) covar(x))
	 V=NULL
	 E=NULL
	 for(g in 2:G){
	 	
	 	V=c(V,Mclust(sim_cv,G=g,modelNames="V")$bic)
	 	E=c(E,Mclust(sim_cv,G=g,modelNames="E")$bic)
	 	
	 	
	 }
	 e=Mclust(sim_cv,G=3,modelNames="V")
	 m=rbind(m,e$parameters$mean)
	 grp1=names(which(e$classification==1))
	 grp2=names(which(e$classification==2))
	 grp3=names(which(e$classification==3))
	 l1=gene*p1
	 l2=(gene*p1)+(gene*p2)
	 l3=gene
	good=rbind(good, c(sum(grp1 %in% genes[1:l1]),sum(grp2 %in% genes[(l1+1):l2]),sum(grp3 %in% genes[(l2+1):l3])))

	 V_bic=rbind(V_bic,V)
	 E_bic=rbind(E_bic,E)
	 
	 }
	 
	 return(list(V_bic=V_bic,E_bic=E_bic,m=m,good=good))
	 }
	 
	 




essai_2_dm=BIC_100(10000,30,0.25,0.5,0.25,3,7,10,1,sqrt(2),sqrt(3),5)
2#best is 3V
par(mfrow=c(2,2))
boxplot(cbind(essai_2_dm$V_bic,essai_2_dm$E_bic),names=c("2-V","3-V","4-V","2-E","3-E","4-E"),ylab="BIC")
mis=cbind(2500-essai_2_dm$good[,1],5000-essai_2_dm$good[,2],2500-essai_2_dm$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 3
plot(1:100,essai_2_dm$V_bic[,1],ylab="BIC",xlab="Simulation number",col="green",ylim=c(-5300,-4400))
points(1:100,essai_2_dm$V_bic[,2],col="black")
points(1:100,essai_2_dm$V_bic[,3],col="red")
leg.txt=c("2","3","4")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")
#best is 3
plot(density(essai_2_dm$V_bic[,1]),xlab="BIC",main="",col="green")
lines(density(essai_2_dm$V_bic[,2]),col="black")
lines(density(essai_2_dm$V_bic[,3]),col="red")
legend(locator(1),lty=1,col=c("green","black","red"),legend=leg.txt,title="# of components")

#3 components always better that 2 and 4
sum(essai_2_dm$V_bic[,2]>essai_2_dm$V_bic[,1])#99
sum(essai_2_dm$V_bic[,2]>essai_2_dm$V_bic[,3])#100
best_2=apply(cbind(essai_2_dm$V_bic,essai_2_dm$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
# 1  2 
# 1 99 

sim2_dm=simulation(10000,30,0.25,0.5,0.25,3,7,10,1,sqrt(2),sqrt(3))
 sim_sd_2_dm=apply(sim2_dm,1,function(x) sd(x))
 e2_dm=Mclust(sim_sd_2_dm)
 summary(e2_dm)#best 3 V
  mis_sd=rowSums(mis)
mean(mis_sd)#2430.4
sd(mis_sd)#93.94



	

essai_mad_2_dm=BIC_100_mad(10000,30,0.25,0.5,0.25,3,7,10,1,sqrt(2),sqrt(3),5)	
par(mfrow=c(2,2))
boxplot(cbind(essai_mad_2_dm$V_bic,essai_mad_2_dm$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_mad_2_dm$good[,1],5000-essai_mad_2_dm$good[,2],2500-essai_mad_2_dm$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")


#best is 3
plot(1:100,essai_mad_2_dm$V_bic[,2],ylab="BIC",xlab="Simulation number",ylim=c(-9300,-8300))
points(1:100,essai_mad_2_dm$V_bic[,3],col="red")
points(1:100,essai_mad_2_dm$V_bic[,4],col="blue")
leg.txt=c("3","4","5")
legend(locator(1),pch=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")
#best is 3
plot(density(essai_mad_2_dm$V_bic[,2]),xlab="BIC",main="")
lines(density(essai_mad_2_dm$V_bic[,3]),col="red")
lines(density(essai_mad_2_dm$V_bic[,4]),col="blue")
legend(locator(1),lty=1,col=c("black","red","blue"),legend=leg.txt,title="# of components")

##3 components nearly always better that 4 and 5 except 5 times for 4 components

sum(essai_mad_2_dm$V_bic[,2]>essai_mad_2_dm$V_bic[,3])#96
sum(essai_mad_2_dm$V_bic[,2]>essai_mad_2_dm$V_bic[,4])#100
best_2=apply(cbind(essai_mad_2_dm$V_bic,essai_mad_2_dm$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
# 2  3  6  8 
#94  4  1  1 
 sim_mad_2_dm=apply(sim2_dm,1,function(x) mad(x))
 e2_mad=Mclust(sim_mad_2_dm)
 summary(e2_mad)#best 3 V
 mis_mad=rowSums(mis)
mean(mis_mad)#3898.75
sd(mis_mad)#86.76






essai_cv_2_dm=BIC_100_cv(10000,30,0.25,0.5,0.25,3,7,10,1,sqrt(2),sqrt(3),5)	
 par(mfrow=c(2,2))

boxplot(cbind(essai_cv_2_dm$V_bic,essai_cv_2_dm$E_bic),names=c("2-V","3-V","4-V","5-V","2-E","3-E","4-E","5-E"),ylab="BIC")
mis=cbind(2500-essai_cv_2_dm$good[,1],5000-essai_cv_2_dm$good[,2],2500-essai_cv_2_dm$good[,3])
boxplot(mis,names=c("Low","Medium","High"),ylab="Misclassification")

#best is 2
plot(1:100,essai_cv_2_dm$V_bic[,1],ylab="BIC",xlab="Simulation number",col="green",ylim=c(29500,30400))
points(1:100,essai_cv_2_dm$V_bic[,2],col="black")
points(1:100,essai_cv_2_dm$V_bic[,3],col="red")
leg.txt=c("2","3","4")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")
#best is 2
plot(density(essai_cv_2_dm$V_bic[,1]),xlab="BIC",main="",col="green")
lines(density(essai_cv_2_dm$V_bic[,2]),col="black")
lines(density(essai_cv_2_dm$V_bic[,3]),col="red")
legend(locator(1),pch=1,col=c("green","black","red"),legend=leg.txt,title="# of components")
#3 components always better that 4 and 5
sum(essai_cv_2_dm$V_bic[,2]>essai_cv_2_dm$V_bic[,1])#76
sum(essai_cv_2_dm$V_bic[,2]>essai_cv_2_dm$V_bic[,3])#100

best_2=apply(cbind(essai_cv_2_dm$V_bic,essai_cv_2_dm$E_bic),1,function(x) which(x==max(x)))
table(best_2)
#best_2
# 1  2 
#24 76 
 

 sim_cv_2_dm=apply(sim2_dm,1,function(x) covar(x))
 e2_cv=Mclust(sim_cv_2_dm)
 summary(e2_cv)#best 3 V
 
  mis_cv=rowSums(mis)
mean(mis_cv)#6872.16
sd(mis_cv)#57.85


 
 save.image("sim_p1_m2_v2.RData")


