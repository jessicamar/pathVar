# simulation<-function(g,n,p1,p2,p3,mean1,mean2,mean3,sigma1,sigma2,sigma3){
	
	# sim_data=NULL
# for(i in 1:(g*p1)){
	
	# sim_data=rbind(sim_data,rnorm(30,mean=mean1,sd=sigma1))
	
# }

# for(i in 1:(g*p2)){
	
	# sim_data=rbind(sim_data,rnorm(30,mean=mean2,sd=sigma2))
	
# }
# for(i in 1:(g*p3)){
	
	# sim_data=rbind(sim_data,rnorm(30,mean=mean3,sd=sigma3))
	
# }


# return(sim_data)
# }



# sim1=simulation(10000,30,0.25,0.5,0.25,9,9,9,1,1.2,1.4)
# g1=as.vector(sim1[1:2500,])
# g2=as.vector(sim1[2501:7500,])
# g3=as.vector(sim1[7501:10000,])


library(ggplot2)
library(plyr)
library(reshape)
 library(gridExtra)
 
      

g1_1=rnorm(30,mean=9,sd=1)
 g2_1=rnorm(30,mean=9,sd=1.2)
 g3_1=rnorm(30,mean=9,sd=1.4)

df=data.frame(cbind(c(g1_1,g2_1,g3_1),c(rep("Group 1",length(g1_1)),rep("Group 2",length(g2_1)),rep("Group 3",length(g3_1)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot1=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle('(a) n=30, mean=(9,9,9) and sd=(1,1.2,1.4)')+xlab("Expression")+scale_x_continuous(limits = c(5, 14))
plot(plot1)  
  
  plot0=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="bottom")+ggtitle('(a) n=30, mean=(9,9,9) and sd=(1,1.2,1.4)')+xlab("Expression")+scale_x_continuous(limits = c(5, 14))

plot(plot0)
  
    
g1_2=rnorm(30,mean=9,sd=1)
 g2_2=rnorm(30,mean=9,sd=sqrt(2))
 g3_2=rnorm(30,mean=9,sd=sqrt(3))

df=data.frame(cbind(c(g1_2,g2_2,g3_2),c(rep("Group 1",length(g1_2)),rep("Group 2",length(g2_2)),rep("Group 3",length(g3_2)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot2=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle(expression(paste("(b) n=30, mean=(9,9,9) and sd=(1,",sqrt(2),",",sqrt(3),")")))+xlab("Expression")+scale_x_continuous(limits = c(3, 15))
plot(plot2)  


g1_3=rnorm(30,mean=9,sd=1)
 g2_3=rnorm(30,mean=9,sd=2)
 g3_3=rnorm(30,mean=9,sd=3)

df=data.frame(cbind(c(g1_3,g2_3,g3_3),c(rep("Group 1",length(g1_3)),rep("Group 2",length(g2_3)),rep("Group 3",length(g3_3)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot3=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle(expression(paste("(c) n=30, mean=(9,9,9) and sd=(1,2,3)")))+xlab("Expression")+scale_x_continuous(limits = c(0, 18))
plot(plot3)  
    

g1_1_2=rnorm(30,mean=3,sd=1)
 g2_1_2=rnorm(30,mean=7,sd=1.2)
 g3_1_2=rnorm(30,mean=10,sd=1.4)

df=data.frame(cbind(c(g1_1_2,g2_1_2,g3_1_2),c(rep("Group 1",length(g1_1_2)),rep("Group 2",length(g2_1_2)),rep("Group 3",length(g3_1_2)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot4=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle('(d) n=30, mean=(3,7,10) and sd=(1,1.2,1.4)')+xlab("Expression")+scale_x_continuous(limits = c(0, 15))
plot(plot4)  
  
    
g1_2_2=rnorm(30,mean=3,sd=1)
 g2_2_2=rnorm(30,mean=7,sd=sqrt(2))
 g3_2_2=rnorm(30,mean=10,sd=sqrt(3))

df=data.frame(cbind(c(g1_2_2,g2_2_2,g3_2_2),c(rep("Group 1",length(g1_2_2)),rep("Group 2",length(g2_2_2)),rep("Group 3",length(g3_2_2)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot5=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle(expression(paste("(e) n=30, mean=(3,7,10) and sd=(1,",sqrt(2),",",sqrt(3),")")))+xlab("Expression")+scale_x_continuous(limits = c(0, 15))
    plot(plot5)  


g1_3_2=rnorm(30,mean=3,sd=1)
 g2_3_2=rnorm(30,mean=7,sd=2)
 g3_3_2=rnorm(30,mean=10,sd=3)

df=data.frame(cbind(c(g1_3_2,g2_3_2,g3_3_2),c(rep("Group 1",length(g1_3_2)),rep("Group 2",length(g2_3_2)),rep("Group 3",length(g3_3_2)))))
is.factor(df[,2])
df[,1]=as.numeric(as.character(df[,1]))
df.m=melt(df)
df.m=df.m[,-2]
color=c("darkorchid1","steelblue1","grey")
colnames(df.m)<-c("Group","value")
     
plot6=  ggplot(na.omit(df.m)) + geom_density(aes(x=value,  y=..density..,colour=Group,fill=Group),alpha=0.3)+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
    panel.background = element_blank(), axis.line = element_line(colour = "black"))+ scale_colour_manual(values=color)+scale_fill_manual(values = color)+theme_bw(base_size = 5)+theme(legend.position="none")+ggtitle('(f) n=30, mean=(3,7,10) and sd=(1,2,3)')+xlab("Expression")+scale_x_continuous(limits = c(0, 17))
plot(plot6)  

    
    


    
   


    g_legend <- function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}

leg<-g_legend(plot0)
tiff("simulation.tiff",width=140,height=100,units="mm",res=300,compression="lzw")
grid.arrange(arrangeGrob(plot1,plot2,plot3,plot4,plot5,plot6,nrow = 2),leg,nrow=2,heights=c(5,1))
dev.off()

save.image("simulation.RData")