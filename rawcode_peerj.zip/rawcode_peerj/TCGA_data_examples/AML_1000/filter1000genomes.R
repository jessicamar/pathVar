# read in RPKM values 660 samples and 53,934 genes
dat <- read.table("GD660.GeneQuantRPKM.txt",header=T,sep="\t",stringsAsFactors=FALSE)
range(dat[,c(-1,-2,-3,-4)]) # 0 to 76148.96
# normalize data
rownames(dat) <- dat[,2] # put gene names as rownames
dat <- dat[,c(-1,-2,-3,-4)] # remove coordinates
dat=log(dat+1,base=2) # new range 0 to 16.21656

# convert ensembl to gene names
modifiedGeneNames <- strsplit(rownames(dat),split="[.]")
modifiedGeneNames <- lapply(modifiedGeneNames, function(x) x[1])
modifiedGeneNames <- unlist(modifiedGeneNames)
rownames(dat.filt) <- modifiedGeneNames
library("AnnotationDbi")
library(org.Hs.eg.db)
convertIDs <- function( ids, from, to, db, ifMultiple=c("putNA", "useFirst")) {
  stopifnot( inherits( db, "AnnotationDb" ) )
  ifMultiple <- match.arg( ifMultiple )
  suppressWarnings( selRes <- AnnotationDbi::select(
    db, keys=ids, keytype=from, columns=c(from,to) ) )
  if ( ifMultiple == "putNA" ) {
    duplicatedIds <- selRes[ duplicated( selRes[,1] ), 1 ]
    selRes <- selRes[ ! selRes[,1] %in% duplicatedIds, ]
  }
  return( selRes[ match( ids, selRes[,1] ), 2 ] )
}
ENSEMBLtoGene <- convertIDs(rownames(dat), "ENSEMBL", "SYMBOL",org.Hs.eg.db)

convertNamesNoNA <- ENSEMBLtoGene[which(!is.na(ENSEMBLtoGene))] # 10363 genes left
convertNamesNoNA[which(duplicated(convertNamesNoNA))] #
l=NULL
for(i in 1:length(na.omit(unique(ENSEMBLtoGene)))){
	print(i)
		l=rbind(l,colMeans(dat[which(ENSEMBLtoGene==(na.omit(unique(ENSEMBLtoGene))[i])),]))
	
}

rownames(l)<-na.omit(unique(ENSEMBLtoGene))

qc <- apply(l, 1, function(x) sum(x>=1))
dat.filt=l[qc >= .75*(dim(dat)[2]),]
dim(dat.filt) # now 10240 genes and 660 samples

write.table(dat.filt,"1000genomesData_2.txt",quote=FALSE,sep="\t",row.names=T,col.names=T)


