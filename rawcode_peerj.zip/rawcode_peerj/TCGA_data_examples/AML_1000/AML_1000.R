dat1000 <- read.table("1000genomesData_2.txt",header=T,sep="\t",stringsAsFactors=FALSE)
genes1000=dat1000[,1]
dat1000=dat1000[,-1]

load("~/real_dataset/TCGA_dataset/AML_1000/AMLRNAseq.RData")

load("~/real_dataset/TCGA_dataset/AML_1000/1000genomes.RData")

cgene.filt=cgene[c_names.filt%in%genes1000,]
rownames(cgene.filt)=c_names.filt[c_names.filt%in%genes1000]
pdf("AML_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(cgene.filt)
dev.off()
dat1000.filt=dat1000[genes1000%in%c_names.filt,]
rownames(dat1000.filt)=genes1000[genes1000%in%c_names.filt]
pdf("1000_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(dat1000.filt)
dev.off()

diagnosticsVarPlots_2 <- function(dat.mat1,dat.mat2) {
    # Compute the sd, mean,cv and mad for each gene
    dat.sd1 <- apply(dat.mat1, 1, sd, na.rm = TRUE)
    dat.avg1 <- rowMeans(dat.mat1, na.rm = TRUE)
    dat.cv1 <- apply(dat.mat1, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad1 <- apply(dat.mat1, 1, mad, na.rm = TRUE)

    dat.sd2 <- apply(dat.mat2, 1, sd, na.rm = TRUE)
    dat.avg2 <- rowMeans(dat.mat2, na.rm = TRUE)
    dat.cv2 <- apply(dat.mat2, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad2 <- apply(dat.mat2, 1, mad, na.rm = TRUE)

    data.sd <- data.frame(standDev = c(dat.sd1,dat.sd2), avg = c(dat.avg1,dat.avg2))
    data.mad <- data.frame(medAbsDev = c(dat.mad1,dat.mad2), avg = c(dat.avg1,dat.avg2))
    data.cv <- data.frame(cv = c(dat.cv1,dat.cv2), avg = c(dat.avg1,dat.avg2))
    # Plot the mean vs the standard deviation and give the correlation between both in the title.
    plotSD <- ggplot(data.sd, aes(x = avg, y = standDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Standard Deviation (SD)") + ggtitle(paste(c("Standard Deviation [ R=", round(cor(data.sd$standDev, 
        data.sd$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the median absolute deviation and give the correlation between both in the title.
    plotMAD <- ggplot(data.mad, aes(x = avg, y = medAbsDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Median Absolute Deviation (MAD)") + ggtitle(paste(c("Median Absolute Deviation [ R=", 
        round(cor(data.mad$medAbsDev, 
        data.mad$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the coefficient of variation and give the correlation between both in the title.
    plotCV <- ggplot(data.cv, aes(x = avg, y = cv)) + geom_point(colour = "grey60") + stat_smooth(method = loess) + 
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), 
            axis.line = element_line(colour = "black")) + xlab("Average") + ylab("Coefficient of Variation (CV)") + 
        ggtitle(paste(c("Coefficient of Variation [ R=", round(cor(data.cv$cv, 
        data.cv$avg), 3), "]"), 
            collapse = " "))
    grid.arrange(arrangeGrob(plotSD, plotMAD, plotCV, nrow = 1))
}

pdf("AML_1000_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots_2(cgene.filt,dat1000.filt)
dev.off()

dat1000.filt.order=dat1000.filt[order(rownames(dat1000.filt)),]

datAML=cbind(cgene.filt,dat1000.filt.order)
dim(datAML)#9060 833

pdf("all_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(datAML)
dev.off()


groups=as.factor(c(rep(1,dim(cgene.filt)[2]),rep(2,dim(dat1000.filt.order)[2])))
library(pathVar)



AML1000KeggCont=pathVarTwoSamplesCont(datAML, pways.kegg,groups=groups,varStat="sd")
write.table(AML1000KeggCont@tablePway, file="table_AML_1000_exact_kegg_SD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_kegg.cont=sigPway(AML1000KeggCont,0.01)
length(sig_kegg.cont@genesInSigPways1)#169


AML1000KeggContMAD=pathVarTwoSamplesCont(datAML, pways.kegg,groups=groups,varStat="mad")
write.table(AML1000KeggContMAD@tablePway, file="table_AML_1000_exact_kegg_MAD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.cont_mad=sigPway(AML1000KeggContMAD,0.01)
length(sig_kegg.cont_mad@genesInSigPways1)#122



AML1000ReactomeCont=pathVarTwoSamplesCont(datAML, pways.reactome,groups=groups,varStat="sd")
write.table(AML1000ReactomeCont@tablePway, file="table_AML_1000_exact_reactome_SD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.cont=sigPway(AML1000ReactomeCont,0.01)
length(sig_reactome.cont@genesInSigPways1)#304

AML1000ReactomeContMAD=pathVarTwoSamplesCont(datAML, pways.reactome,groups=groups,varStat="mad")
write.table(AML1000ReactomeContMAD@tablePway, file="table_AML_1000_exact_reactome_MAD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_reactome.cont_mad=sigPway(AML1000ReactomeContMAD,0.01)
length(sig_reactome.cont_mad@genesInSigPways1)#198



AML1000KeggDisc=pathVarTwoSamplesDisc(datAML, pways.kegg,test="exact",groups=groups,varStat="sd")
write.table(AML1000KeggDisc@tablePway, file="table_AML_1000_exact_kegg_SD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_kegg.disc=sigPway(AML1000KeggDisc,0.01)#0


AML1000KeggDiscMAD=pathVarTwoSamplesDisc(datAML, pways.kegg,test="exact",groups=groups,varStat="mad")
write.table(AML1000KeggDiscMAD@tablePway, file="table_AML_1000_exact_kegg_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.disc_mad=sigPway(AML1000KeggDiscMAD,0.01)
length(sig_kegg.disc_mad@genesInSigPways1)#186



AML1000ReactomeDisc=pathVarTwoSamplesDisc(datAML, pways.reactome,test="exact",groups=groups,varStat="sd")
write.table(AML1000ReactomeDisc@tablePway, file="table_AML_1000_exact_reactome_SD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.disc=sigPway(AML1000ReactomeDisc,0.01)
length(sig_reactome.disc@genesInSigPways1)#3



AML1000ReactomeDiscMAD=pathVarTwoSamplesDisc(datAML, pways.reactome,test="exact",groups=groups,varStat="mad")
write.table(AML1000ReactomeDiscMAD@tablePway, file="table_AML_1000_exact_reactome_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.disc_mad=sigPway(AML1000ReactomeDiscMAD,0.01)
length(sig_reactome.disc_mad@genesInSigPways1)#444





#MEan

AML1000KeggDisc_mean=pathVarTwoSamplesDisc(datAML, pways.kegg,test="exact",groups=groups,varStat="mean")
write.table(AML1000KeggDisc_mean@tablePway, file="table_AML_1000_exact_kegg_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

AML1000ReactomeDisc_mean=pathVarTwoSamplesDisc(datAML, pways.reactome,test="exact",groups=groups,varStat="mean")
write.table(AML1000ReactomeDisc_mean@tablePway, file="table_AML_1000_exact_reactome_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)


sig_kegg.disc_mean=sigPway(AML1000KeggDisc_mean,0.01)
sig_reactome.disc_mean=sigPway(AML1000ReactomeDisc_mean,0.01)

length(sig_kegg.disc_mean@genesInSigPways1)#250
length(sig_reactome.disc_mean@genesInSigPways1)#713

intersect(names(sig_kegg.disc_mean@genesInSigPways1),names(sig_kegg.disc_mad@genesInSigPways1))#186
intersect(names(sig_reactome.disc_mean@genesInSigPways1),names(sig_reactome.disc_mad@genesInSigPways1))#440


save.image("AML_1000_sd_mad_mean.RData")


vs <- apply(datAML, 1, function(x) mad(x, na.rm = TRUE))
var_1 <- AML1000ReactomeDiscMAD@var1
var_2 <- AML1000ReactomeDiscMAD@var2

cut <- quantile(vs, probs = c(1/3, 2/3))
    mixAML <- rep(NA, dim(datAML)[1])
    mixAML[var_1 <= cut[1]] <- 1
    mixAML[var_1 <= cut[2] & var_1 > cut[1]] <- 2
    mixAML[var_1 > cut[2]] <- 3
    names(mixAML) <- row.names(datAML)
    # In which cluster each gene is
    mix1000 <- rep(NA, dim(datAML)[1])
    mix1000[var_2 <= cut[1]] <- 1
    mix1000[var_2 <= cut[2] & var_2 > cut[1]] <- 2
    mix1000[var_2 > cut[2]] <- 3
    names(mix1000) <- row.names(datAML)

table(mixAML)
#   1    2    3 
#3967 2196 2897 

table(mix1000)
#   1    2    3 
#6306 1723 1031 

pathAML <- as.data.frame(table(mixAML))
colnames(pathAML) <- c("Cluster", "Number_of_genes")

path1000 <- as.data.frame(table(mix1000))
colnames(path1000) <- c("Cluster", "Number_of_genes")
 plotPathAML <- ggplot(pathAML, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("AML") + xlab("") + ylim(0, 6306)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
 
  plotPath1000 <- ggplot(path1000, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("1000 Genomes") + xlab("") + ylim(0, 6306)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
  pdf("AMLVS1000Counts.pdf",width=10,height=7)
  grid.arrange(arrangeGrob(plotPathAML, plotPath1000, nrow = 1))
  dev.off()

  