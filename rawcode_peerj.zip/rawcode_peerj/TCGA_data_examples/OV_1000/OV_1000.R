

load("~/real_dataset/TCGA_dataset/OV_1000/OVRNAseq.RData")

load("~/real_dataset/TCGA_dataset/OV_1000/1000genomes.RData")

cgene.filt=cgene[c_names.filt%in%genes1000,]
rownames(cgene.filt)=c_names.filt[c_names.filt%in%genes1000]
pdf("OV_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(cgene.filt)
dev.off()

dat1000.filt=dat1000[genes1000%in%c_names.filt,]
rownames(dat1000.filt)=genes1000[genes1000%in%c_names.filt]
pdf("1000_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(dat1000.filt)
dev.off()

diagnosticsVarPlots_2 <- function(dat.mat1,dat.mat2) {
    # Compute the sd, mean,cv and mad for each gene
    dat.sd1 <- apply(dat.mat1, 1, sd, na.rm = TRUE)
    dat.avg1 <- rowMeans(dat.mat1, na.rm = TRUE)
    dat.cv1 <- apply(dat.mat1, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad1 <- apply(dat.mat1, 1, mad, na.rm = TRUE)

    dat.sd2 <- apply(dat.mat2, 1, sd, na.rm = TRUE)
    dat.avg2 <- rowMeans(dat.mat2, na.rm = TRUE)
    dat.cv2 <- apply(dat.mat2, 1, function(x) {
        sd(x, na.rm = TRUE)/mean(x, na.rm = TRUE)
    })
    dat.mad2 <- apply(dat.mat2, 1, mad, na.rm = TRUE)

    data.sd <- data.frame(standDev = c(dat.sd1,dat.sd2), avg = c(dat.avg1,dat.avg2))
    data.mad <- data.frame(medAbsDev = c(dat.mad1,dat.mad2), avg = c(dat.avg1,dat.avg2))
    data.cv <- data.frame(cv = c(dat.cv1,dat.cv2), avg = c(dat.avg1,dat.avg2))
    # Plot the mean vs the standard deviation and give the correlation between both in the title.
    plotSD <- ggplot(data.sd, aes(x = avg, y = standDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Standard Deviation (SD)") + ggtitle(paste(c("Standard Deviation [ R=", round(cor(data.sd$standDev, 
        data.sd$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the median absolute deviation and give the correlation between both in the title.
    plotMAD <- ggplot(data.mad, aes(x = avg, y = medAbsDev)) + geom_point(colour = "grey60") + 
        stat_smooth(method = loess) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) + xlab("Average") + 
        ylab("Median Absolute Deviation (MAD)") + ggtitle(paste(c("Median Absolute Deviation [ R=", 
        round(cor(data.mad$medAbsDev, 
        data.mad$avg), 3), "]"), collapse = " "))
    # Plot the mean vs the coefficient of variation and give the correlation between both in the title.
    plotCV <- ggplot(data.cv, aes(x = avg, y = cv)) + geom_point(colour = "grey60") + stat_smooth(method = loess) + 
        theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), 
            axis.line = element_line(colour = "black")) + xlab("Average") + ylab("Coefficient of Variation (CV)") + 
        ggtitle(paste(c("Coefficient of Variation [ R=", round(cor(data.cv$cv, 
        data.cv$avg), 3), "]"), 
            collapse = " "))
    grid.arrange(arrangeGrob(plotSD, plotMAD, plotCV, nrow = 1))
}

pdf("OV_1000_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots_2(cgene.filt,dat1000.filt)
dev.off()


dat1000.filt.order=dat1000.filt[order(rownames(dat1000.filt)),]

datOV=cbind(cgene.filt,dat1000.filt.order)
dim(datOV)#9102  969

pdf("all_filter_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(datOV)
dev.off()

groups=as.factor(c(rep(1,dim(cgene.filt)[2]),rep(2,dim(dat1000.filt.order)[2])))
library(pathVar)



OV1000KeggCont=pathVarTwoSamplesCont(datOV, pways.kegg,groups=groups,varStat="sd")
write.table(OV1000KeggCont@tablePway, file="table_OV_1000_exact_kegg_SD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_kegg.cont=sigPway(OV1000KeggCont,0.01)
length(sig_kegg.cont@genesInSigPways1)#215

OV1000KeggContMAD=pathVarTwoSamplesCont(datOV, pways.kegg,groups=groups,varStat="mad")
write.table(OV1000KeggContMAD@tablePway, file="table_OV_1000_exact_kegg_MAD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.cont_mad=sigPway(OV1000KeggContMAD,0.01)
length(sig_kegg.cont_mad@genesInSigPways1)#221

OV1000ReactomeCont=pathVarTwoSamplesCont(datOV, pways.reactome,groups=groups,varStat="sd")
write.table(OV1000ReactomeCont@tablePway, file="table_OV_1000_exact_reactome_SD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.cont=sigPway(OV1000ReactomeCont,0.01)
length(sig_reactome.cont@genesInSigPways1)#598


OV1000ReactomeContMAD=pathVarTwoSamplesCont(datOV, pways.reactome,groups=groups,varStat="mad")
write.table(OV1000ReactomeContMAD@tablePway, file="table_OV_1000_exact_reactome_MAD_cont.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_reactome.cont_mad=sigPway(OV1000ReactomeContMAD,0.01)
length(sig_reactome.cont_mad@genesInSigPways1)#229


OV1000KeggDisc=pathVarTwoSamplesDisc(datOV, pways.kegg,test="exact",groups=groups,varStat="sd")
write.table(OV1000KeggDisc@tablePway, file="table_OV_1000_exact_kegg_SD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_kegg.disc=sigPway(OV1000KeggDisc,0.01)#0

OV1000KeggDiscMAD=pathVarTwoSamplesDisc(datOV, pways.kegg,test="exact",groups=groups,varStat="mad")
write.table(OV1000KeggDiscMAD@tablePway, file="table_OV_1000_exact_kegg_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.disc_mad=sigPway(OV1000KeggDiscMAD,0.01)
length(sig_kegg.disc_mad@genesInSigPways1)#176


OV1000ReactomeDisc=pathVarTwoSamplesDisc(datOV, pways.reactome,test="exact",groups=groups,varStat="sd")
write.table(OV1000ReactomeDisc@tablePway, file="table_OV_1000_exact_reactome_SD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.disc=sigPway(OV1000ReactomeDisc,0.01)#0

OV1000ReactomeDiscMAD=pathVarTwoSamplesDisc(datOV, pways.reactome,test="exact",groups=groups,varStat="mad")
write.table(OV1000ReactomeDiscMAD@tablePway, file="table_OV_1000_exact_reactome_MAD_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

sig_reactome.disc_mad=sigPway(OV1000ReactomeDiscMAD,0.01)
length(sig_reactome.disc_mad@genesInSigPways1)#352
intersect(names(sig_kegg.disc_mean@genesInSigPways1),names(sig_kegg.disc_mad@genesInSigPways1))#173
intersect(names(sig_reactome.disc_mean@genesInSigPways1),names(sig_reactome.disc_mad@genesInSigPways1))#350




#MEan

OV1000KeggDisc_mean=pathVarTwoSamplesDisc(datOV, pways.kegg,test="exact",groups=groups,varStat="mean")
write.table(OV1000KeggDisc_mean@tablePway, file="table_OV_1000_exact_kegg_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)

OV1000ReactomeDisc_mean=pathVarTwoSamplesDisc(datOV, pways.reactome,test="exact",groups=groups,varStat="mean")
write.table(OV1000ReactomeDisc_mean@tablePway, file="table_OV_1000_exact_reactome_MEAN_disc.txt", sep="\t", col.names=T, row.names=F, quote=F)


sig_kegg.disc_mean=sigPway(OV1000KeggDisc_mean,0.01)
sig_reactome.disc_mean=sigPway(OV1000ReactomeDisc_mean,0.01)

length(sig_kegg.disc_mean@genesInSigPways1)#247
length(sig_reactome.disc_mean@genesInSigPways1)#715



save.image("OV_1000_sd_mad_mean.RData")

vs <- apply(datOV, 1, function(x) sd(x, na.rm = TRUE))
var_1 <- OV1000ReactomeDisc@var1
var_2 <- OV1000ReactomeDisc@var2

cut <- quantile(vs, probs = c(1/3, 2/3))
    mixOV <- rep(NA, dim(datOV)[1])
    mixOV[var_1 <= cut[1]] <- 1
    mixOV[var_1 <= cut[2] & var_1 > cut[1]] <- 2
    mixOV[var_1 > cut[2]] <- 3
    names(mixOV) <- row.names(datOV)
    # In which cluster each gene is
    mix1000 <- rep(NA, dim(datOV)[1])
    mix1000[var_2 <= cut[1]] <- 1
    mix1000[var_2 <= cut[2] & var_2 > cut[1]] <- 2
    mix1000[var_2 > cut[2]] <- 3
    names(mix1000) <- row.names(datOV)

table(mixOV)
#   1    2    3 
#9087 9 6

table(mix1000)
#   1 
#9102 

library(ggplot2)
library(gridExtra)
pathOV <- as.data.frame(table(mixOV))
colnames(pathOV) <- c("Cluster", "Number_of_genes")

path1000 <- data.frame(Cluster=c(1,2,3),Number_of_genes=c(9102,0,0))
path1000$Cluster=as.factor(path1000$Cluster)
 plotPathOV <- ggplot(pathOV, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("OVC") + xlab("") + ylim(0, 9102)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
 
  plotPath1000 <- ggplot(path1000, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("1000 Genomes") + xlab("") + ylim(0, 9102)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
  pdf("OVVS1000Counts_SD.pdf",width=10,height=7)
  grid.arrange(arrangeGrob(plotPathOV, plotPath1000, nrow = 1))
  dev.off()

  
vs <- apply(datOV, 1, function(x) mad(x, na.rm = TRUE))
var_1 <- OV1000ReactomeDiscMAD@var1
var_2 <- OV1000ReactomeDiscMAD@var2

cut <- quantile(vs, probs = c(1/3, 2/3))
    mixOV <- rep(NA, dim(datOV)[1])
    mixOV[var_1 <= cut[1]] <- 1
    mixOV[var_1 <= cut[2] & var_1 > cut[1]] <- 2
    mixOV[var_1 > cut[2]] <- 3
    names(mixOV) <- row.names(datOV)
    # In which cluster each gene is
    mix1000 <- rep(NA, dim(datOV)[1])
    mix1000[var_2 <= cut[1]] <- 1
    mix1000[var_2 <= cut[2] & var_2 > cut[1]] <- 2
    mix1000[var_2 > cut[2]] <- 3
    names(mix1000) <- row.names(datOV)

table(mixOV)
#   1    2    3 
#5923 1932 1247

table(mix1000)
#   1   2    3
#8190  653  259 

library(ggplot2)
library(gridExtra)
pathOV <- as.data.frame(table(mixOV))
colnames(pathOV) <- c("Cluster", "Number_of_genes")

path1000 <- as.data.frame(table(mix1000))
colnames(path1000) <- c("Cluster", "Number_of_genes")
 plotPathOV <- ggplot(pathOV, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("OVC") + xlab("") + ylim(0, 8190)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
 
  plotPath1000 <- ggplot(path1000, aes(x = Cluster, y = Number_of_genes, fill = Cluster)) + geom_bar(stat = "identity", color = "black", fill = "darkorchid1") + ylab("Number of genes") + theme(legend.position = "none") + ggtitle("1000 Genomes") + xlab("") + ylim(0, 8190)+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),panel.background = element_blank(), axis.line = element_line(colour = "black"))
  pdf("OVVS1000Counts_MAD.pdf",width=10,height=7)
  grid.arrange(arrangeGrob(plotPathOV, plotPath1000, nrow = 1))
  dev.off()

  




