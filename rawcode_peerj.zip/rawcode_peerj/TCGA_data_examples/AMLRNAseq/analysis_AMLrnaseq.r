
load("~/real_dataset/TCGA_dataset/AMLRNAseq/AMLRNAseq.RData")
library(pathVar)

dat=cgene
rownames(dat)=c_names.filt
dim(dat)#14681   173
pdf("AML_diagnostics.pdf",width=15,height=7)
diagnosticsVarPlots(dat)
dev.off()



#getPvalue exact test

# kegg
t0 <- Sys.time() 
exact.test.kegg <- pathVarOneSample(dat, pways=pways.kegg,test="exact",varStat="sd")
t1 <- Sys.time()
t1-t0
#Time difference of 10.8403 mins
write.table(exact.test.kegg@tablePway, file="table_AMLRNAseq_exact_kegg_SD.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome <- pathVarOneSample(dat, pways=pways.reactome,test="exact",varStat="sd")
t1 <- Sys.time()
t1-t0
#Time difference of 18.72654 mins

write.table(exact.test.reactome@tablePway, file="table_AMLRNAseq_exact_reactome_SD.txt", sep="\t", col.names=T, row.names=F, quote=F)



#sig category exact
sig_kegg.exact=sigPway(exact.test.kegg,0.01)
sig_reactome.exact=sigPway(exact.test.reactome,0.01)

#save as pdf exact
saveAsPDF(exact.test.kegg,sig_kegg.exact)
saveAsPDF(exact.test.reactome,sig_reactome.exact)

######MAD

t0 <- Sys.time() 
exact.test.kegg_mad <- pathVarOneSample(dat, pways=pways.kegg,test="exact",varStat="mad")
t1 <- Sys.time()
t1-t0
#Time difference of 10.96668 mins
write.table(exact.test.kegg_mad@tablePway, file="table_AMLRNAseq_exact_kegg_MAD.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_mad <- pathVarOneSample(dat, pways=pways.reactome,test="exact",varStat="mad")
t1 <- Sys.time()
t1-t0
#Time difference of 18.72654 mins

write.table(exact.test.reactome_mad@tablePway, file="table_AMLRNAseq_exact_reactome_MAD.txt", sep="\t", col.names=T, row.names=F, quote=F)



#sig category exact
sig_kegg.exact_mad=sigPway(exact.test.kegg_mad,0.01)
sig_reactome.exact_mad=sigPway(exact.test.reactome_mad,0.01)


#save as pdf exact
saveAsPDF(exact.test.kegg_mad,sig_kegg.exact_mad)
saveAsPDF(exact.test.reactome_mad,sig_reactome.exact_mad)


#Mean
library(pathVar)
# kegg
t0 <- Sys.time() 
exact.test.kegg_mean <- pathVarOneSample(dat, pways=pways.kegg,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 10.59639 mins
write.table(exact.test.kegg_mean@tablePway, file="table_AMLRNAseq_exact_kegg_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)


# reactome
t0 <- Sys.time() 
exact.test.reactome_mean <- pathVarOneSample(dat, pways=pways.reactome,test="exact",varStat="mean")
t1 <- Sys.time()
t1-t0
#Time difference of 18.72654 mins

write.table(exact.test.reactome_mean@tablePway, file="table_AMLRNAseq_exact_reactome_MEAN.txt", sep="\t", col.names=T, row.names=F, quote=F)
sig_kegg.exact_mean=sigPway(exact.test.kegg_mean,0.01)
sig_reactome.exact_mean=sigPway(exact.test.reactome_mean,0.01)

length(sig_kegg.exact_mean@genesInSigPways1)#130
length(sig_reactome.exact_mean@genesInSigPways1)#396

intersect(names(sig_kegg.exact_mean@genesInSigPways1),names(sig_kegg.exact_mad@genesInSigPways1))#48
intersect(names(sig_reactome.exact_mean@genesInSigPways1),names(sig_reactome.exact_mad@genesInSigPways1))#248


save.image("AMLRNAseq_sd_mad_mean.RData")

